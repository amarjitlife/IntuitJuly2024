

package learnKotlin

/*
Compiling Kotlin Code
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

Running Compiled Jar File
java -jar functions.jar
*/

//______________________________________________________________

// WHAT IS A FUNCTION?
//		It's Callable/Invokable

// Function Types
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ) = a + b
fun sub( a: Int, b: Int ) = a - b
fun mul( a: Int, b: Int ) = a * b

// Function Types
//		(Int, Int, Int) -> Int
fun sum3( a: Int, b: Int, c: Int ) = a + b + c

// Polymporphic Function
//		Mechanism : By Passing Funtion To Function

// Higher Order Function
//		Functions Which Can Take Functions Arguments And/Or Return Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b  )
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result: Int

	// ::sum Is Reference/Addresses To Function sum
	// ::sub Is Reference/Addreeses To Function sub

	result = calculator( a, b, ::sum )
	println("Result : $result ")

	result = calculator( a, b, ::sub )
	println("Result : $result ")

	result = calculator( a, b, ::mul )
	println("Result : $result ")

	// What Is The Type Of something?
	var something = ::sum
	var somethingAgain: (Int, Int) -> Int  = ::sum
	result = something( 100, 200 )
	println("Result : $result ")	
	result = somethingAgain( 100, 200 )
	println("Result : $result ")	

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> b
	//	but KFunction2<Int, Int, Int> was expected
	// something = ::sum3	

	// What Is The Type Of somethingMore?
	var somethingMore: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = somethingMore( a, b, ::sum )
	println("Result : $result ")	
}


//______________________________________________________________

fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	fun moveForward( start: Int ) : Int {
		return start + 1
	}

	fun moveBackward( start: Int ) : Int {
		return start - 1
	}

	return if ( backward ) ::moveBackward else ::moveForward
}


fun someDummyFunction( some: Int ) : Int {
	return 99
}

fun playWithChooseStepsFunction() {
	val something: (Int) -> Int = chooseSteps( backward = true )
	val somethingAgain = chooseSteps( backward = false )

	println( something(10) )
	println( something( -10 ))

	println( somethingAgain( 10 ))
	println( somethingAgain( -10 ))

	// What is Type Of somethingMore?
	val somethingMore = ::chooseSteps

	val somethingMoreAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	
// Exception in thread "main" kotlin.reflect.jvm.internal.KotlinReflectionInternalError: 
	// Function 'moveBackward' (JVM signature: chooseSteps$moveBackward(I)I) not resolved in 
	// class kotlin.jvm.internal.Intrinsics$Kotlin: no members found

	// println( somethingMore( true ) )
	// println( somethingMoreAgain( false ) )

	val something1 		= somethingMore( true )
	val somethingAgain1 = somethingMoreAgain( false )

	// println( something1 )
	// println( somethingAgain1 )

	// println( something1( 10) )
	// println( somethingAgain1( 10 ))

	println( ::someDummyFunction )
	val someFunction = ::someDummyFunction
	println( someFunction )
}

//______________________________________________________________


fun moveTowardsZero( start: Int ) : () -> Int { // Enclosing Context
	// Local Functions
	//		Functions Defined Inside Another Function
	var something = 999 // Local Variable

	fun moveForward() : Int { // Local Function // Enclosed Context
		// Enclosed Context Captures The Enclsoing Context

		// In Some Languages
		//		Programme Move something Heap
		// In Kotlin
		//		something Will Be Move Heap In Wrapper Object
		///		That Wrapper Object Reference Is Referred Here
		something = something + 10
		return something
	}

	fun moveBackward() : Int { // Local Function
		something = something - 10
		return something
	}

	return if ( start > 0 ) ::moveBackward else ::moveForward
}

fun playWithLocalFunctions() {
	val something 		= moveTowardsZero( 10 ) 
	val somethingAgain  = moveTowardsZero( -10 ) 

	var result: Int 

	result = something()
	println("Result : $result")

	result = somethingAgain()
	println("Result : $result")
}


//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithChooseStepsFunction")
	playWithChooseStepsFunction()

	println("\nFunction: playWithLocalFunctions")
	playWithLocalFunctions()

	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

