
package learnKotlin

/*
Compiling Kotlin Code
kotlinc KotlinClasses.kt -include-runtime -d classes.jar

Running Compiled Jar File
java -jar classes.jar
*/

//______________________________________________________________

// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// DESIGN DECISION
//		Best Practices Are Becoming Part of Langauge Design

// BEST PRACTICE
//		 Classes Must Be FINAL If Not Meant To Be Inherited

// In Kotlin
//		 By Default Classes Are Final
//				Final Classes Are Not Inheritable
//		 By Default Members Are Final
//				Final Members Cann't Be Overridden

// In Java
//		 By Default Classes Are Open
//				Open Classes Are Inheritable
//		 By Default Members Are Open
//				Open Members Can Be Overridden

// error: this type is final, so it cannot be inherited from
// error: 'click' in 'View' is final and cannot be overridden
open class View {
	open fun click() = println("View: click Called...") 
}

// Inheritance Button Is Subclass and View Is Parent/Superclass
class Button : View() {
	override fun click() 	= println("Button: click Called...")
	fun magic() 			= println("Button: magic Called...")
}

fun playWithClassesInheritance() {
	val vo = View()
	vo.click()

	val bo = Button()
	bo.click()
	bo.magic()

	// Setting Perceptive
	// Seeing Sub Type Object w.r.t Super Type i.e. Parent Class
	val viewAgain : View = Button()
	viewAgain.click()
	// error: unresolved reference: magic
	// viewAgain.magic()

	// Resetting Percpetive To Sub Type i.e.. Child Class
	val buttonBack: Button = viewAgain as Button
	buttonBack.magic()
}

// Function : playWithClassesInheritance
// View: click Called...
// Button: click Called...
// Button: magic Called...
// Button: click Called...

//______________________________________________________________

open class Parent {
	open fun doStudy() 		= println("Parent: Study Well")
	open fun doEarn() 	 	= println("Parent: Earn Well")
	fun getMarried() 		= println("Parent: Get Married")
}

class Child : Parent() {
	override fun doStudy() = println("Child: Studied Well")
	override fun doEarn()  = println("Child: Earned Well")
	fun playCricket() 	   = println("Child: Play Cricket!")
	fun someSmoking() 	   = println("Have Some Exploration In Life!!!")
}

fun playWithParentAndChild() {
	val someKid: Parent = Child()

	someKid.doStudy()
	someKid.doEarn()
	someKid.getMarried()
	// parent.playCricket()
	// parent.someSmoking()

	val friend = someKid as Child
	friend.playCricket()
	friend.someSmoking()
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction : playWithClassesInheritance")
	playWithClassesInheritance()

	println("\nFunction : playWithParentAndChild")
	playWithParentAndChild()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

