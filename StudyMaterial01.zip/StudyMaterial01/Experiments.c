
#include <stdio.h> 
#include <limits.h>

int sum( int a, int b ) {
	return a + b;
}


void playWithSum() {
	int a, b, result = 0;

	a = 2147483647;
	b = 2;
	result = sum( a, b );
	printf("\nResult : %d", result );

	a = -2147483648;
	b = -2;
	result = sum( a, b );
	printf("\nResult : %d", result );
}



signed int summation(signed int a, signed int b) {
  signed int result = 0;

	// Type Safe Code: Respecting Type Defintion  
  if (((b > 0) && (a > (INT_MAX - b))) ||
      ((b < 0) && (a < (INT_MIN - b)))) {
    /* Handle error */
    printf("Cann't Calculate Sum For Given Values")
  } else {
    result = a + b;
  }
    return result;
  /* ... */
}


int main() {
	printf("\nFunction: playWithSum" );
	playWithSum();

	return 0;
}

// Function: playWithSum
// Result : -2147483647
// Result :  2147483646
