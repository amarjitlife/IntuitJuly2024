
package learnKolin


import java.util.Random
import java.util.TreeMap


/*
1. Download Kotlin Compiler
		kotlin-compiler-2.0.0.zip

2. Unzip Kotlin Compiler
		kotlin-compiler-2.0.0.zip

3. Set PATH Variable
	export KOTLIN_PATH="~/Documents/Softwares/kotlinc/bin/" 
	export PATH=$PATH:$JAVA_PATH:$ANDROID_PATH:$SWIFT_HOME:$KOTLIN_PATH 
*/

/*
Compiling Kotlin Code
kotlinc KotlinFoundation.kt -include-runtime -d foundation.jar

Running Compiled Jar File
java -jar foundation.jar
*/

//______________________________________________________________

// DESIGN PRINCIPLE
//		Expressiveness
//		Determinism

fun helloWorld() {
	println("Hello World!!!");
}

// Expression: A Statment With Return Value

fun max( a: Int, b: Int ): Int {
	return if ( a > b ) a else b
}


// DESIGN QUESTION
//		Function Are First Citizen Or/Not?

// In Kotlin
//		Functions Are First Class Citizen In Language
//			Can Be Assigned A Value
//			Can Be Passed/Returned From A Function

fun maximum( a: Int, b: Int ): Int = if ( a > b ) a else b

fun playWithMaximum() {
	println( max( 100, 200 ) )
	println( max( 300, -200 ) )	

	println( maximum( 100, 200 ) )
	println( maximum( 300, -200 ) )	
}


//______________________________________________________________

// Kotlin Compiler Will Generate
//		1. Memberwise Constructor
//		2. Getter For name Property
//		3. Getter and Setter For isMarried Property

// val Means Immutability Property
// var Means Mutable Property

class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	val gabbar = Person("Gabbar Singh", false )

	println( gabbar.name ) // gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

// error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Decoit"
	gabbar.isMarried = true

	println( gabbar.name ) // gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()	
}

//______________________________________________________________


class Rectangle( val height: Int, val width: Int ) {
	// Member Property With Custom Getter
	val isSquare: Boolean
		get() { // Custome Getter
			return height == width
		}

		// error: a 'val'-property cannot have a setter
		// set() {
		// 
		// }
}

// import java.util.Random

fun playWithRectangle() {
	val rectangle1 = Rectangle( height = 100, width = 200 )
	println( rectangle1.width )
	println( rectangle1.height )
	println( rectangle1.isSquare )

	println(" ${rectangle1.width}, ${rectangle1.height}" )

	val rectangle2 = Rectangle( height = 200, width = 200 )
	println( rectangle2.width) 
	println(rectangle2.height )
	println( rectangle2.isSquare )

	val rectangle3 = Rectangle( 200, 200 )
	println( rectangle3.width) 
	println( rectangle3.height )
	println( rectangle3.isSquare )

	val random = Random()
	val rectangle4 = Rectangle( random.nextInt(), random.nextInt() )
	println(" ${rectangle4.width}, ${rectangle4.height}" )

}

//______________________________________________________________

enum class Colour(val r: Int, val g: Int, val b: Int ) {
	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 )
}


fun playWithEnumClass() {
	println( Colour.BLUE )
	println( Colour.BLUE.r )
	println( Colour.BLUE.g )
	println( Colour.BLUE.b )
}


//______________________________________________________________

// DESIGN PRINCPLE
//		Design  Towards Determinism Rather Than Non Determinism

// 	Corollary:
//		Always Prefer Excautive Cases Over else/Default Branch

// Color Type
//		Range = { RED, GREEN, BLUE, ORANGE, YELLOW, UKNOWN }

enum class Color(val r: Int, val g: Int, val b: Int ) {
	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 ),
	ORANGE( 200, 200, 2000 ), YELLOW( 100, 100, 100 ),
	UNKOWN( 0, 0, 0 )
}

fun getColorName( color: Color ) : String {
	return when( color ) {
		// Type Safe Code
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE 		-> "Blue Color"
		Color.ORANGE 	-> "Orange Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.UNKOWN 	-> "Unknown Color"
	}
}

fun getColorNameAgain( color: Color ) : String = when( color ) {
	// Type Unsafe Code
	Color.RED 	-> "Red Color"
	Color.GREEN -> "Green Color"
	Color.BLUE 	-> "Blue Color"

	// Black Hole
	else 		-> "Unknown Color" // Default Branch
// 	error: 'when' expression must be exhaustive, 
//	add necessary 'ORANGE' branch or 'else' branch instead
}


// error: the integer literal does not conform to the expected type String
// fun getColorNameOnceAgain( color: Color ): String = when( color ) {

// Following Two Lines of Code Are Equivalent
// fun getColorNameOnceAgain( color: Color ): Any = when( color ) {
fun getColorNameOnceAgain( color: Color ) = when( color ) {
	// when Is A Type Safe Expression
	Color.RED 		-> "Red Color"
	Color.GREEN 	-> "Green Color"
	Color.BLUE 		-> "Blue Color"
	Color.ORANGE 	-> "Orange Color"
	Color.YELLOW 	-> "Yellow Color"
	// Color.YELLOW 	-> 99
	Color.UNKOWN 	-> "Unknown Color"
}


fun getColorNature( color: Color ) : String {
	return when( color ) {
		Color.RED, Color.ORANGE 	-> "Warm Color"
		Color.GREEN 				-> "Cold Color"
		Color.BLUE, Color.YELLOW 	-> "Neutral Color"
		Color.UNKOWN 				-> "Unknown Color"
	}
}

fun playWithColors() {
	println( getColorName( Color.RED ))
	println( getColorName( Color.GREEN ))
	println( getColorName( Color.BLUE ))

	println( getColorNameAgain( Color.RED ))
	println( getColorNameAgain( Color.GREEN ))
	println( getColorNameAgain( Color.BLUE ))

	println( getColorNameOnceAgain( Color.RED ))
	println( getColorNameOnceAgain( Color.GREEN ))
	println( getColorNameOnceAgain( Color.BLUE ))

	println( getColorNature( Color.RED ))
	println( getColorNature( Color.GREEN ))
	println( getColorNature( Color.BLUE ))
}


//______________________________________________________________

// DESIGN PRINCIPLE
//		Exceptions Are Not That Excetional Such That It Breaks Design

// “All happy families are alike; each unhappy family is unhappy in its own way.”
//		 ― Leo Tolstoy , Anna Karenina

// enum class Color(val r: Int, val g: Int, val b: Int ) {
// 	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 ),
// 	ORANGE( 200, 200, 2000 ), YELLOW( 100, 100, 100 )
// }

fun mixColors( c1: Color, c2: Color ) : Color = when( setOf(c1, c2 ) ) {
	setOf( Color.RED, Color.YELLOW ) 	-> Color.ORANGE
	setOf( Color.YELLOW, Color.BLUE ) 	-> Color.GREEN
	// else -> "Dirty Color"
	// else -> throw Exception("Dirty Color")
	else 								-> Color.UNKOWN
}

fun playWithMixingColors() {
	println( mixColors( Color.RED, Color.YELLOW ))
	println( mixColors( Color.BLUE, Color.YELLOW ))
	// println( mixColors( Color.BLUE,  Color.RED))
}

//______________________________________________________________
// SMART CASTING

// Type Expr
interface Expr

// Type Num and Sum
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

fun eval( e: Expr ) : Int {
	// What Is Type Of e?
	// e Type Expr

	// Checking e Is Type Of Num
	//		If True Than Type Cast To Num Type
	if ( e is Num ) { // Smart Casting
		// What Is Type Of e?
		// e Will Be Of Type Num
		return e.value
	}

	// What Is Type Of e?
	// e Type Expr
	if ( e is Sum ) {
		// What Is Type Of e?
		// e Will Be Of Type Sum
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEval() {
	// 10 + 20
	println( eval( Sum( Num(10), Num(20) ) ))
	// (10 + 20 ) + 200
	println( eval( Sum( Sum( Num(10), Num(20) ), Num(200) ) ) )
}

//______________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr) : Expr

fun evalAgain( e: Expr ) : Int = if ( e is Num ) {
		e.value
	} else if ( e is Sum ) {
		evalAgain( e.left ) + evalAgain( e.right )
	} else {
		throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalAgain() {
	// 10 + 20
	println( evalAgain( Sum( Num(10), Num(20) ) ))
	// (10 + 20 ) + 200
	println( evalAgain( Sum( Sum( Num(10), Num(20) ), Num(200) ) ) )
}

//______________________________________________________________
// Kotlin Thinking Style

fun evaluate( e: Expr ) : Int = when ( e ) {
	is Num -> e.value
	is Sum -> evaluate( e.left ) + evaluate( e.right )
	else   -> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvaluate() {
	// 10 + 20
	println( evaluate( Sum( Num(10), Num(20) ) ))
	// (10 + 20 ) + 200
	println( evaluate( Sum( Sum( Num(10), Num(20) ), Num(200) ) ) )
}

//______________________________________________________________

fun fizzBuzz( some : Int ) = when { // PATTERN MATCHING
	some % 15 == 0 -> "FizzBuzz"
	some % 3  == 0 -> "Fizz"
	some % 5  == 0 -> "Buzz"
	else -> "${some} "
}

fun fizzyBuzzyThings() {
	// .. Range Operator
	for ( i in 1..100 ) {
		print( fizzBuzz( i ))
	}

	for ( i in 100 downTo 1 step 2 ) {
		print( fizzBuzz( i ))		
	}
}

//______________________________________________________________

// import java.util.TreeMap

fun playWithMaps() {
	// In Kotlin
	//		Using Java Collections APIs Directly In Kotlin
	val binaryRepresentation = TreeMap<Char, String>()
	// In Java
	// final TreeMap<Char, String> binaryRepresentation = new TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary
	}

	for ( ( letter, binary ) in binaryRepresentation ) {
		println(" $letter = $binary ")
	}
}

//______________________________________________________________

fun isLetter( character : Char ) = character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character: Char ) = character !in '0'..'9'


fun recognise( character : Char ) = when( character ) {
	in '0'..'9' -> "It's Digit"
	in 'a'..'z', in 'A'..'Z' -> "It's A Leter"
	else -> "Unknown Character!"
}

//______________________________________________________________

fun playWithCollectionsInKotlin() {
	// Kotlin APIs for Collections
	//		Kotlin APIs Are Written On Top Of Java Collections ONLY
	val set 	= hashSetOf( 11, 77, 99, 88 )
	val list 	= arrayListOf( 11, 77, 99, 88 )
	val map 	= hashMapOf( 1 to "One", 10 to "Ten", 50 to "Fifty" )

	println( set.javaClass )
	println( list.javaClass )
	println( map.javaClass )

	// Kotlin APIs for Collections
	val strings = listOf( "First", "Second", "Third", "One", "Two ")
	println( strings.last() )
	println( strings.javaClass )

	// Kotlin APIs for Collections
	val numbers = setOf( 11, 88, 88, 99, 11 )
	println( numbers.javaClass )
	println( numbers.maxOrNull() )
}

// Function: playWithCollectionsInKotlin
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// Two 
// class java.util.Arrays$ArrayList
// class java.util.LinkedHashSet
// 99

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction: helloWorld")
	helloWorld()

	println("\nFunction: playWithMaximum")
	playWithMaximum()

	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithEnumClass")
	playWithEnumClass()

	println("\nFunction: playWithColors")
	playWithColors()

	println("\nFunction: playWithMixingColors")
	playWithMixingColors()

	println("\nFunction: playWithEval")
	playWithEval()

	println("\nFunction: playWithEvalAgain")
	playWithEvalAgain()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	println("\nFunction: fizzyBuzzyThings")
	fizzyBuzzyThings()

	println("\nFunction: playWithMaps")	
	playWithMaps()

	println("\nFunction: playWithCollectionsInKotlin")
	playWithCollectionsInKotlin()

	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

