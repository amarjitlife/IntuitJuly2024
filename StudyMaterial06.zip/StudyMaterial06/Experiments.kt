

fun moveTowardsZero(start: Int): String { 
    println(start);
    return when { // updated to use a when expression instead of an if-else expression
        (start == 0) -> "Reached Zero"
        (start > 0) -> moveTowardsZero(start - 1)         
         (start < 0) -> moveTowardsZero(start + 1) 
    }
}

