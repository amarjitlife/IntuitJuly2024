/*
// Compiling Java Code
javac TestInnerClass.java 

// Running Java Code
java TestInnerClass 
*/

import java.io.Serializable; 
import java.io.IOException;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.File;

//_________________________________________________________________________

class NonSerializableServer {
    String greeting = "Good Morning!";

    // BAD: The following class is serializable, but the enclosing class
    // 'NonSerializableServer' is not. Serializing an instance of 'WrongSession' 
    // causes a 'java.io.NotSerializableException'.

    // INNER CLASS
    class WrongSession implements Serializable {
        // WILL CAPTURE OUTER CLASS CONTEXT
        // It Will Store Locally
        //  this@NonSerializableServer
        private static final long serialVersionUID = 8970783971992397218L;
        private int id;
        private String user;
        
        WrongSession(int id, String user) { 
            this.id = id;
            this.user = user;
        }

        @Override
        public String toString() {
            return greeting;
        }
    }
    
    WrongSession ws = new WrongSession();

    public WrongSession getNewSession(String user) {
        System.out.println("NonSerializableServer: getNewSession Called");
        return new WrongSession( 111, user);
    }
}

//_________________________________________________________________________

class SerializableServer {
    // GOOD: The following class can be correctly serialized because it is static.

    // NESTED CLASS
    static class Session implements Serializable {
        private static final long serialVersionUID = 1065454318648105638L;
        private int id;
        private String user;
        
        Session(int id, String user) { 
            this.id = id;
            this.user = user; 
        }
    }
    
    public Session getNewSession(String user) {
        System.out.println("SerializableServer: getNewSession Called");
        return new Session( 999 , user);
    }
}

//_________________________________________________________________________


public class TestInnerClass {

    public static void main(String[] args) throws IOException {
        NonSerializableServer server = new NonSerializableServer();

        NonSerializableServer.WrongSession session = server.getNewSession("Gabbar Singh");
        System.out.println( session );
      
        // UNCOMMENT FOLLOWING CODE
        // try{
        //     FileOutputStream fos = new FileOutputStream("Serialize.ser");
        //     ObjectOutputStream oos = new ObjectOutputStream(fos);
        //     oos.writeObject(session);
        // } catch(Exception e){
        //     e.printStackTrace();
        // }

        SerializableServer serverAgain = new SerializableServer();
        SerializableServer.Session sessionAgain = serverAgain.getNewSession("Gabbar Singh");
        
        try{
            FileOutputStream fos = new FileOutputStream("Serialize.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(sessionAgain);
        } catch(Exception e){
            e.printStackTrace();
        }
    }
}

//_________________________________________________________________________
//_________________________________________________________________________
//_________________________________________________________________________
//_________________________________________________________________________
