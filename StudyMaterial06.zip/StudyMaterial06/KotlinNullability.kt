
package learnKotlin

//______________________________________________________________


// In Kotlin
//		All References Are NON-NULLABLE By Default

// In Java
//		All References Are NULLABLE By Default


// DESIGN PRACTICE
//		1. Design Towards Non NUllability Rather Than Nullability
//		2. Nullability Have To Brought In Design Based Sound Reasoning
//		3. Handle Nullability As Early As Possible
//		4. Resist Temptation To Propogate Nullability
//		5. Always Prefer Nullables Over Exceptions

fun playWithNullabilityAndNonNullability() {
	// NON NULLABLE TYPES
	var name: String = "Gabbar"
	var age: Int = 30

	println( name )
	println( age )
	name = "Gabbar Singh"
	age = 99
	println( name )
	println( age )

// KotlinNullability.kt:17:9: error: null can not be a value of a non-null type String
// KotlinNullability.kt:18:8: error: null can not be a value of a non-null type Int
	// name = null 	
	// age = null

	// Optional Types/ NULLABLE TYPES
	var name1: String? = "Gabbar"
	var age1: Int? = 30

	println( name1 )
	println( age1 )
	name1 = null 
	age1 = null
	println( name1 )
	println( age1 )
}


// Human gabbar = new Human("Gabbar");
// if ( gabbar != null) { gabbar.dance(); } else { }
// if ( gabbar != null) { gabbar.shoot(); } else { }

//______________________________________________________________

fun playWithNullabilityAndNonNullabilityAgain() {
	var authorName: String? = "Joe Howard"
    var authorAge: Int? = 24

    println(authorName)
    println(authorAge)

    // ?.  Is Safe Member Access
    // Compiler Will Generate Following Code For RHS
    //						if (autherAge != null ) autherAgae.plus(1) else null
    val ageAfterBirthday0 = authorAge?.plus( 1 )

    // Use Rarest Rare Case
    // authorAge = null
    val ageAfterBirthday1 = authorAge!! + 1

	var nonNullableAuthor: String = ""
    var nullableAuthor: String? = ""

    // Convert NUllability To NON NUllability As Early As Possible
    if (authorName != null) {
        nonNullableAuthor = authorName
    } else {
        nullableAuthor = authorName
    }

    println(nonNullableAuthor)
    println(nullableAuthor)

    // ?. is Safe Calls Operator
    var nameLength = authorName?.length
    // Above Line Of Code Is Equvalent To Following Line Of Code
    // 		if (authorName != null) authorName else null
    println("Author's name has length $nameLength.")

    // OPTIONAL CHAINING
    val nameLengthPlus5 = authorName?.length?.plus(5)
    println("Author's name length plus 5 is $nameLengthPlus5.")
}


//______________________________________________________________


fun playWithElvisOperator() {	
	var something: String? = "Good Morning!"
	println(something)
	// something = null
	// println(something)

	// Coding Style 1
	// Nullable Types Data Must Accessed After Checking For null Value
	if (something != null ) {
		val upperValue = something.uppercase()
		println("$upperValue")
	} else {
		println("It Contains >>> Null Value...")
	}

	// Coding Style 2 
	val upperSomething0 = if (something != null ) something else "" 

	// Coding Style 3
	// ?: Is Elvis Operator
	val upperSomething1 = something ?: "" // ?: DEFAULT VALUE
}


//______________________________________________________________


fun playWithNullableColelctions() {
	var nullableList: List<Int>? = listOf(10, 20, 30, 40)

	println( nullableList?.get( 0 ) )
	nullableList = null
	println( nullableList )

	var nullableList1: List<Int?> = listOf(10, 20, null, 40)
	println( nullableList1 )
	// nullableList1 = null
	println( nullableList1 )

	var nullableList2: List<Int?>? = listOf(10, 20, null, 40)
	println( nullableList2 )
	nullableList2 = null
	println( nullableList2 )
}


//______________________________________________________________

data class Employee( val name: String, val manager: Employee? )

// fun getManagerName( employee: Employee ) : String? {
fun getManagerName( employee: Employee ) : String {
// 	error: type mismatch: inferred type is String? but String was expected
	//return employee.manager?.name

	// Better Design
	//		Converting Nullability To Non Nullability
	return employee.manager?.name ?: "UNamed"	
}

fun playWithEmployeeManager() {
	val ceo = Employee("Boss", null)
	val samba = Employee("Samba", Employee("Gabbar", null) )

	// Following Have What Type?
	//		String?
	// val someone1: String? = getManagerName( ceo )

	val someone1: String = getManagerName( ceo )
	val someone2 = getManagerName( samba )
}

// KotlinNullability.kt:152:9: error: type mismatch: inferred type is String? but Unit was expected
// 	return employee.manager?.name
//         ^
// KotlinNullability.kt:160:25: error: type mismatch: inferred type is Unit but String was expected
// 	val someone1: String = getManagerName( ceo )

//______________________________________________________________

// Address Class Have 4 Non Nullable Properties
class Address(
	val streetName: String,
	val zipCode: Int,
	val city: String,
	val country: String
)

// Conpany Class Have 2 Properties
//		name Is NON Nullable Property
//		address Is Nullable Property
class Company( val name: String, val address: Address? )

// Person Class Have 2 Properties
class Person( val name: String, val company: Company? )
//		name Is NON Nullable Property
//		company Is Nullable Property

fun getCountryNameOfPersonCompany(person: Person) : String  {
	// In RHS Expression, If Anything Becomes null 
	// Than Whole RHS Expression Will Becomes Of null Value 

	// error: type mismatch: inferred type is String? but String was expected
	// val country: String = person.company?.address?.country
	val country: String? = person.company?.address?.country

	return if (country != null) country else "Unknown"
}

fun playWithPersonCountry() {
	val alice = Person("Alice", null) 		// company is null
	println( getCountryNameOfPersonCompany(alice) )

	val bobCompany = Company("IBM", null) 	// Company's address is null
	val bob = Person("Bob", bobCompany)
	println( getCountryNameOfPersonCompany(bob) )

	val intelAddress = Address("Outer Ring Road", 560103, "Bangalore", "India")
	val rameshCompany = Company("Intel", intelAddress)
	val rammesh = Person("Bob", rameshCompany)
	println( getCountryNameOfPersonCompany(rammesh) )
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fun main() {
	println("\nFunction : playWithNullabilityAndNonNullability")
	playWithNullabilityAndNonNullability()

	println("\nFunction : playWithNullabilityAndNonNullabilityAgain")
	playWithNullabilityAndNonNullabilityAgain()

	println("\nFunction : playWithElvisOperator")
	playWithElvisOperator()

	println("\nFunction : playWithNullableColelctions")
	playWithNullableColelctions()

	println("\nFunction : playWithEmployeeManager")
	playWithEmployeeManager()

	println("\nFunction : playWithPersonCountry")
	playWithPersonCountry()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

