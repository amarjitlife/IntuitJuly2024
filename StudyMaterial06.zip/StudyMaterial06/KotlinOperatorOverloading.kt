

package learnKotlin

import java.math.BigDecimal


//______________________________________________________________

data class Point( var x: Int, var y: Int ) {
	operator fun plus( other: Point ) : Point {
		println("\nFunction::  plus Called...")
		val xx = x + other.x
		val yy = y + other.y
		return Point( xx, yy )
	}

	operator fun minus( other: Point ) : Point {
		println("\nFunction::  plus Called...")
		val xx = x - other.x
		val yy = y - other.y
		return Point( xx, yy )
	}
}

fun playWithPoints() {
	val point1 = Point(11, 22 )
	val point2 = Point(100, 200 )

	val point3 = Point( point1.x + point2.x, point1.y + point2.y )
	println( point1 )
	println( point2 )
	println( point3 )

	val point33 = point1 + point2 // point1.plus(point2)
	println( point33 )	

	val point44 = point1 - point2 // point1.minus(point2)
	println( point44 )	
}


//______________________________________________________________

operator fun Point.times( scale: Double ): Point {
	val xx =  ( x * scale ).toInt()
	val yy = ( y * scale ).toInt()

	return Point( xx, yy )
}

operator fun Char.times( count: Int ): String {
	return toString().repeat(count)
}

fun playWithTimesOperator() {
	val point1 = Point(11, 22 )
	val point2 = Point(100, 200 )

	val point3 = point1 * 10.0 // point1.times( 10.0 )
	val point4 = point2 * 2.0	 // point2.times( 2.0 )

	println( point1 )
	println( point2 )
	println( point3 )
	println( point4 )	

	var character = 'A'
	var result = character * 10
	println( result )

	character = '_'
	result = character * 40

	println( result )
}


//______________________________________________________________

// import java.math.BigDecimal

operator fun BigDecimal.inc() = this + BigDecimal.ONE

fun playWithBigDecimalIncrementOperator() {
	var bigNumber = BigDecimal.ZERO

	println(bigNumber)
	bigNumber++			// Compiler Will Convert It To bigNumber.inc()
	println(bigNumber)
	bigNumber++			// Compiler Will Convert It To bigNumber.inc()
	println(bigNumber)
}

//______________________________________________________________


class Person(val firstName: String, val lastName: String, val age: Int): Comparable<Person> {
	override fun compareTo(other: Person) : Int {
		return compareValuesBy(this, other, Person::firstName, Person::lastName)
	}
}

fun playWithPersonComparison() {
	val person1 = Person("Alice", "Carols", 20)
	val person2 = Person("Alice", "Carolina", 29)
	var person3 = Person("Ramesh", "Kumar", 30)

	println( person1 < person2 ) // person1.compareTo(person2)
	println( person2 > person3 ) // person2.compareTo(person3)
	println( person1 < person3 ) // person1.compareTo(person3)
}

//______________________________________________________________

operator fun Point.get( index: Int ) : Int {
	return when( index ) {
		0 -> x
		1 -> y
		else -> throw IndexOutOfBoundsException("Index Out Of Bound...")
	}
}

operator fun Point.set( index: Int, value: Int ) {
	when( index ) {
		0 -> x = value
		1 -> y = value
		else -> throw IndexOutOfBoundsException("Index Out Of Bound...")
	}
}

fun playWithIndexingOperator() {
	val point = Point(11, 22)

	println( point[0] ) // point.get( 0 )
	println( point[1] )

	point[0] = 111 // point.set( 0, 111 )
	point[1] = 222 // point.set( 1, 222 )

	println( point[0] )
	println( point[1] )
}


//______________________________________________________________


data class Rectangle(val upperLeft: Point, val lowerRight: Point )

operator fun Rectangle.contains(point: Point) : Boolean {
	val xCoordinateInsideRectanleXs = point.x in upperLeft.x until lowerRight.x
	val yCoordinateInsideRectanleYs = point.y in upperLeft.y until lowerRight.y
	
	return  xCoordinateInsideRectanleXs && yCoordinateInsideRectanleYs	   
}


fun playWithInOperator() {
	val rectangle = Rectangle( Point(10, 20), Point(50, 80))
	
	var point = Point(40, 40)
	// Checking Point Is Inside A Rectangle or Not?
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(100, 100)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(30, 40)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)

	point = Point(0, 0)
	println( point in rectangle ) // Compiler Will Convert It To rectangle.contains(point)
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fun main() {
	println("\nFunction : playWithPoints")
	playWithPoints()

	println("\nFunction : playWithTimesOperator")
	playWithTimesOperator()

	println("\nFunction : playWithPersonComparison")
	playWithPersonComparison()

	println("\nFunction : playWithIndexingOperator")
	playWithIndexingOperator()

	println("\nFunction : playWithInOperator")
	playWithInOperator()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

