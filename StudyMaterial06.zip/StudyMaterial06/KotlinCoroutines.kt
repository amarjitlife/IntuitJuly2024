
package learnKotlin

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // this: CoroutineScope L1, C1

    launch { // launch a new coroutine and continue L2, C2
        delay(1000L) // non-blocking delay for 1 second (default time unit is ms)
        println("World!") // print after delay
    }
    
    println("Hello") // main coroutine continues while a previous one is delayed
	
}

// A coroutine is an instance of a suspendable computation. 
// It is conceptually similar to a thread, in the sense that it takes 
// a block of code to run that works concurrently with the rest of the code. 
// However, a coroutine is not bound to any particular thread. 

// It may suspend its execution in one thread and resume in another one.

// launch is a coroutine builder. 
// It launches a new coroutine concurrently with the rest of the code, 
// which continues to work independently. 

// delay is a special suspending function. 
// It suspends the coroutine for a specific time. 
// Suspending a coroutine does not block the underlying thread, 
// but allows other coroutines to run and use the underlying thread for their code.

// runBlocking is also a coroutine builder 
// that bridges the non-coroutine world of a regular fun main() and 
// the code with coroutines inside of runBlocking { ... } curly braces. 

// The name of runBlocking means that the thread that runs it 
// (in this case — the main thread) gets blocked for the duration of the call, 
// until all the coroutines inside runBlocking { ... } complete their execution. 
// You will often see runBlocking used like that at the very top-level of the application 
// and quite rarely inside the real code, as threads are expensive resources and blocking 
// them is inefficient and is often not desired.

// Structured concurrency﻿
// Coroutines follow a principle of structured concurrency 
// which means that new coroutines can only be launched in a specific CoroutineScope 
// which delimits the lifetime of the coroutine.

// In a real application, you will be launching a lot of coroutines. 
// Structured concurrency ensures that they are not lost and do not leak. 

// An outer scope cannot complete until all its children coroutines complete. 
// Structured concurrency also ensures that any errors in the code are 
// properly reported and are never lost.

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // this: CoroutineScope
    launch { 
    	doWorld() 
    }
    println("Hello")
}

// this is your first suspending function
suspend fun doWorld() {
    delay(1000L)
    println("World!")
}

// This is your first suspending function. 
// Suspending functions can be used inside coroutines just like regular functions, 
// but their additional feature is that they can, in turn, use other suspending 
// functions (like delay in this example) to suspend execution of a coroutine.

//______________________________________________________________

import kotlinx.coroutines.*

// Scope builder﻿
// In addition to the coroutine scope provided by different builders, 
// it is possible to declare your own scope using the coroutineScope builder. 
// It creates a coroutine scope and does not complete until all launched children complete.

// runBlocking and coroutineScope builders may look similar because they both wait 
// for their body and all its children to complete. 

// The main difference is that the runBlocking method blocks the current thread for waiting, 
// while coroutineScope just suspends, releasing the underlying thread for other usages. 
// Because of that difference, runBlocking is a regular function and coroutineScope 
// is a suspending function.

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking { // this: CoroutineScope
    launch { 
    	doWorld() 
        hello()
    }
    println("Hello")
}

// this is your first suspending function
suspend fun doWorld() {
    delay(1000L)
    println("World!")
}

fun hello() {
    println("Hhhhhhh")
}

//______________________________________________________________

import kotlinx.coroutines.*

// Sequentially executes doWorld followed by "Done"
fun main() = runBlocking {
    doWorld()
    println("Done")
}

// Concurrently executes both sections
suspend fun doWorld() = coroutineScope { // this: CoroutineScope
    launch {
        delay(2000L)
        println("World 2")
    }
 
    launch {
        delay(1000L)
        println("World 1")
    }
 
    println("Hello")
}

// A coroutineScope builder can be used inside any suspending function 
// to perform multiple concurrent operations. 
// Let's launch two concurrent coroutines inside a doWorld suspending function:

//______________________________________________________________

import kotlinx.coroutines.*

val job = launch { // launch a new coroutine and keep a reference to its Job
    delay(1000L)
    println("World!")
}

println("Hello")
job.join() // wait until child coroutine completes
println("Done") 


//______________________________________________________________


// Coroutines are less resource-intensive than JVM threads. 
// Code that exhausts the JVM's available memory when using threads 
// can be expressed using coroutines without hitting resource limits

import kotlinx.coroutines.*

fun main() = runBlocking {
    repeat(50_000) { // launch a lot of coroutines
        launch {
//             delay(5L)
            print(".")
        }
    }
    println("Hello")
}

//______________________________________________________________


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {

	val channel = Channel<Int>()

	launch {
	    // this might be heavy CPU-consuming computation or async logic, 
	    // we'll just send five squares
	    for (x in 1..5) channel.send(x * x)
	}

	// here we print five received integers:
	repeat(5) { println(channel.receive()) }
	println("Done!")

}

// A Channel is conceptually very similar to BlockingQueue. 
// One key difference is that instead of a blocking put 
// operation it has a suspending send, and instead of a blocking 
// take operation it has a suspending receive.


//______________________________________________________________

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {

	val channel = Channel<Int>()
	launch {
	    for (x in 1..5) channel.send(x * x)
	    channel.close() // we're done sending
	}

	// here we print received values using `for` loop (until the channel is closed)
	for (y in channel) println(y)
	println("Done!")
}

// Unlike a queue, a channel can be closed to indicate that no more elements are coming. 
// On the receiver side it is convenient to use a regular for loop to 
// receive elements from the channel.

// Conceptually, a close is like sending a special close token to the channel. 
// The iteration stops as soon as this close token is received, 
// so there is a guarantee that all previously sent elements before the close are received:

//______________________________________________________________

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*


fun CoroutineScope.produceSquares(): ReceiveChannel<Int> = produce {
    for (x in 1..5) send(x * x)
}

fun main() = runBlocking {
    val squares = produceSquares()

    squares.consumeEach { 
    	println(it) 
    }
    
    println("Done!")

}

// There is a convenient coroutine builder named produce that makes 
// it easy to do it right on producer side, and an 
// extension function consumeEach, that replaces a for loop on the consumer side:


//______________________________________________________________


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {

    val numbers = produceNumbers() // produces integers from 1 and on
    val squares = square(numbers) // squares integers
    repeat(5) {
        println(squares.receive()) // print first five
    }
    println("Done!") // we are done
    coroutineContext.cancelChildren() // cancel children coroutines

}

// Pipelines﻿
// A pipeline is a pattern where one coroutine is producing, 
//  	possibly infinite, stream of values:
fun CoroutineScope.produceNumbers() = produce<Int> {
    var x = 1
    while (true) send(x++) // infinite stream of integers starting from 1
}

fun CoroutineScope.square(numbers: ReceiveChannel<Int>): ReceiveChannel<Int> = produce {
    for (x in numbers) send(x * x)
}


//______________________________________________________________


import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking<Unit> {

    val channel = Channel<Int>(4) // create buffered channel
    val sender = launch { // launch sender coroutine
        repeat(10) {
            println("Sending $it") // print before sending each element
            channel.send(it) // will suspend when buffer is full
        }
    }
    // don't receive anything... just wait....
    delay(1000)
    sender.cancel() // cancel sender coroutine
    
}

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    val job = launch {
        repeat(1000) { i ->
            println("job: I'm sleeping $i ...")
            delay(500L)
        }
    }
    delay(1300L) // delay a bit
    println("main: I'm tired of waiting!")
    job.cancel() // cancels the job
    job.join() // waits for job's completion 
    println("main: Now I can quit.")    
}

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    val startTime = System.currentTimeMillis()
    val job = launch( Dispatchers.Default) {
        var nextPrintTime = startTime
        var i = 0

        while (isActive) { // cancellable computation loop
            // print a message twice a second
            if (System.currentTimeMillis() >= nextPrintTime) {
                println("job: I'm sleeping ${i++} ...")
                nextPrintTime += 500L
            }
        }
    }

    delay(1300L) // delay a bit
    println("main: I'm tired of waiting!")
    job.cancelAndJoin() // cancels the job and waits for its completion
    println("main: Now I can quit.")
    
}


//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    val job = launch {
        try {
            repeat(1000) { i ->
                println("job: I'm sleeping $i ...")
                delay(500L)
            }
        } finally {
            println("job: I'm running finally")
        }
    }
    delay(1300L) // delay a bit
    println("main: I'm tired of waiting!")
    job.cancelAndJoin() // cancels the job and waits for its completion
    println("main: Now I can quit.")
    
}

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    val job = launch {
        try {
            repeat(1000) { i ->
                println("job: I'm sleeping $i ...")
                delay(500L)
            }
        } finally {
            withContext(NonCancellable) {
                println("job: I'm running finally")
                delay(1000L)
                println("job: And I've just delayed for 1 sec because I'm non-cancellable")
            }
        }
    }
    delay(1300L) // delay a bit
    println("main: I'm tired of waiting!")
    job.cancelAndJoin() // cancels the job and waits for its completion
    println("main: Now I can quit.")
    
}


//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking {

    withTimeout(1300L) {
        repeat(1000) { i ->
            println("I'm sleeping $i ...")
            delay(500L)
        }
    }

}

//______________________________________________________________

import kotlinx.coroutines.*
import kotlin.system.*

fun main() = runBlocking<Unit> {

    val time = measureTimeMillis {
        val one = async { doSomethingUsefulOne() }
        val two = async { doSomethingUsefulTwo() }
        println("The answer is ${one.await() + two.await()}")
    }
    println("Completed in $time ms")
    
}

suspend fun doSomethingUsefulOne(): Int {
    delay(1000L) // pretend we are doing something useful here
    return 13
}

suspend fun doSomethingUsefulTwo(): Int {
    delay(1000L) // pretend we are doing something useful here, too
    return 29
}

// Conceptually, async is just like launch. 
// It starts a separate coroutine which is a light-weight thread t
// hat works concurrently with all the other coroutines. 
// The difference is that launch returns a Job and does not carry any resulting value, 
// while async returns a Deferred — a light-weight non-blocking future that 
// represents a promise to provide a result later. You can use .await() on a 
// deferred value to get its eventual result, but Deferred is also a Job, 
// so you can cancel it if needed.

//______________________________________________________________

import kotlinx.coroutines.*
import kotlin.system.*

fun main() = runBlocking<Unit> {

    val time = measureTimeMillis {
        val one = async(start = CoroutineStart.LAZY) { doSomethingUsefulOne() }
        val two = async(start = CoroutineStart.LAZY) { doSomethingUsefulTwo() }
        // some computation
        one.start() // start the first one
        two.start() // start the second one
        println("The answer is ${one.await() + two.await()}")
    }
    println("Completed in $time ms")
    
}

suspend fun doSomethingUsefulOne(): Int {
    delay(1000L) // pretend we are doing something useful here
    return 13
}

suspend fun doSomethingUsefulTwo(): Int {
    delay(1000L) // pretend we are doing something useful here, too
    return 29
}

//______________________________________________________________

import kotlinx.coroutines.*

fun main() = runBlocking<Unit> {
    try {
        failedConcurrentSum()
    } catch(e: ArithmeticException) {
        println("Computation failed with ArithmeticException")
    }
}

suspend fun failedConcurrentSum(): Int = coroutineScope {

    val one = async<Int> { 
        try {
            delay(Long.MAX_VALUE) // Emulates very long computation
            42
        } finally {
            println("First child was cancelled")
        }
    }

    val two = async<Int> { 
        println("Second child throws an exception")
        throw ArithmeticException()
    }

    one.await() + two.await()
}


//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________



