

class FirstClass {

}

class SecondClass {

}

public class HelloWorld {
    public static void main(String []args) {
        System.out.println("Hello World Java!!!");

        FirstClass first = new FirstClass();
    }
};

