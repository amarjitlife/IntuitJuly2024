

package learnKotlin

/*
Compiling Kotlin Code
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

Running Compiled Jar File
java -jar functions.jar
*/

//______________________________________________________________

// WHAT IS A FUNCTION?
//		It's Callable/Invokable

// Function Types
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ) = a + b
fun sub( a: Int, b: Int ) = a - b
fun mul( a: Int, b: Int ) = a * b

// Function Types
//		(Int, Int, Int) -> Int
fun sum3( a: Int, b: Int, c: Int ) = a + b + c

// Polymporphic Function
//		Mechanism : By Passing Funtion To Function

// Higher Order Function
//		Functions Which Can Take Functions Arguments And/Or Return Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b  )
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result: Int

	result = calculator( a, b, ::sum )
	println("Result : $result ")

	result = calculator( a, b, ::sub )
	println("Result : $result ")

	result = calculator( a, b, ::mul )
	println("Result : $result ")

	// What Is The Type Of something?
	var something = ::sum
	var somethingAgain: (Int, Int) -> Int  = ::sum
	result = something( 100, 200 )
	println("Result : $result ")	
	result = somethingAgain( 100, 200 )
	println("Result : $result ")	

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> b
	//	but KFunction2<Int, Int, Int> was expected
	// something = ::sum3	

	// What Is The Type Of somethingMore?
	var somethingMore: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = somethingMore( a, b, ::sum )
	println("Result : $result ")	
}


//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

