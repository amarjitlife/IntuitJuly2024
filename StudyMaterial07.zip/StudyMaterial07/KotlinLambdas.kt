//______________________________________________________________

// WHAT IS A FUNCTION?
//		It's Callable/Invokable

// Function Types
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ) = a + b
fun sub( a: Int, b: Int ) = a - b
fun mul( a: Int, b: Int ) = a * b

// Function Types
//		(Int, Int, Int) -> Int
fun sum3( a: Int, b: Int, c: Int ) = a + b + c

// Polymporphic Function
//		Mechanism : By Passing Funtion To Function

// Higher Order Function
//		Functions Which Can Take Functions Arguments And/Or Return Functions

// Function Type
//		(Int, Int, (Int, Int) -> Int ) -> Int

// DEFINITION DRIVEN DESIGN
//		Some Invariant Code Block: C
//			Derivative Of C w.r.t. Time Is Zero
//		Hence Invariant Code C

// Invariant Code: Function Signature i.e. Function Name, Arguments and Return Type
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b  )
}

fun playWithCalculator() {
	val a = 40
	val b = 20
	var result: Int

	// ::sum Is Reference/Addresses To Function sum
	// ::sub Is Reference/Addreeses To Function sub

	result = calculator( a, b, ::sum )
	println("Result : $result ")

	result = calculator( a, b, ::sub )
	println("Result : $result ")

	result = calculator( a, b, ::mul )
	println("Result : $result ")

	// What Is The Type Of something?
	var something = ::sum
	var somethingAgain: (Int, Int) -> Int  = ::sum
	result = something( 100, 200 )
	println("Result : $result ")	
	result = somethingAgain( 100, 200 )
	println("Result : $result ")	

	// error: type mismatch: inferred type is KFunction3<Int, Int, Int, Int> b
	//	but KFunction2<Int, Int, Int> was expected
	// something = ::sum3	

	// What Is The Type Of somethingMore?
	var somethingMore: (Int, Int, (Int, Int) -> Int ) -> Int = ::calculator
	result = somethingMore( a, b, ::sum )
	println("Result : $result ")	
}


//______________________________________________________________

// Invariant Code: Function Signature i.e. Function Name, Arguments and Return Type
// fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
// 		return operation( a, b  )
// }

fun playWithCalculatorAgain() {
	val aa = 40
	val bb = 20
	var result: Int

	// Lamba Expression
	val addLambda: (Int, Int) -> Int  = { a: Int, b: Int -> a + b }
	val subLambda  = { a: Int, b: Int -> a - b }

	result = calculator( aa, bb,  addLambda )
	println("Result : $result ")

	result = calculator( aa, bb, subLambda )
	println("Result : $result ")

	result = calculator( aa, bb,  { a: Int, b: Int -> a + b })
	println("Result : $result ")

	result = calculator( aa, bb,  { a: Int, b: Int -> a + b })
	println("Result : $result ")
}


//______________________________________________________________

fun playWithLambdas() {
	// Creating Variable multiplyLambda Of Function Type (Int, Int) -> Int
    var multiplyLambda: (Int, Int) -> Int
    var lambdaResult: Int

    val multiplyLambda0 = { a: Int, b: Int -> a * b }
    lambdaResult = multiplyLambda0(4, 2) // 8
    println(lambdaResult)

    // Defining Lambda Expression Which Takes 2 Int Arguments And Return Int
    multiplyLambda = { a: Int, b: Int -> Int
        a * b
    }

    // Invoking Lambda Expression multiplyLambda
    lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)

    // Defining Lambda Expression Which Takes 2 Int Arguments And Return Int
    //		Arguments and Return Types Can Be Skipped
    //		Implicitly Deduced/Inferrenced
    multiplyLambda = { a, b ->
        a * b
    }

    // Invoking Lambda Expression multiplyLambda
	lambdaResult = multiplyLambda(4, 2) // 8
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Implicitly Inferred Type Of doubleLambda Will Be (Int) -> Int
    val doubleLambda = { a: Int -> 2 * a }
	lambdaResult = doubleLambda(4) 
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword
    val doubleLambdaAgain: (Int) -> Int = { it * 2 }
	lambdaResult = doubleLambdaAgain(4) // 8
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
    //		Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword 
    val square: (Int) -> Int = { number: Int -> number * number }
	lambdaResult = square(4) // 8
    println(lambdaResult)

    // Definining Lambda Expression Which Takes One Int Argument And Returns Int
  	//	Explicitly Added Type Of doubleLambdaAgain Will Be (Int) -> Int
    //		Lambda Expression Which Takes One Argument
    //			Than That Argument Can Be Accessed Using it Keyword 
    val squareAgain: (Int) -> Int = { it * it }
	lambdaResult = squareAgain(4) // 8
    println(lambdaResult)
}

//______________________________________________________________


fun playWithLambdasAgain() {
    var resultReturned : Int 

    // Local Function
    // Defining Function Inside A Function
    fun operateOnNumbers(a: Int, b: Int, operation: (Int, Int) -> Int ): Int {
        val result = operation(a, b) // Invoking Lambda And Passing Parameters
        return result
    }

    // Defining A Lamba Expression
    //		Having Function Type : (Int, Int) -> Int
    val addLambda = { a: Int, b: Int -> a + b }
    resultReturned = operateOnNumbers(4, 2, operation = addLambda)
    println(resultReturned)

    // Creating Function Of Type (Int, Int) -> Int
    fun addFunction(a: Int, b: Int) = a + b

    //							Passing Last Argument As Function Reference
    resultReturned = operateOnNumbers(4, 2, operation = ::addFunction)
    println(resultReturned)

    resultReturned = operateOnNumbers( 4, 2, { a: Int, b: Int -> a + b } )
    println(resultReturned)

    // Another Way To Structure Above 2 Lines Of Code
    resultReturned = operateOnNumbers( 4, 2,
        operation = { a: Int, b: Int ->
            a + b
        }
    )
    println(resultReturned)

    // Skipping Arguments Type In Lamdba Expression
	//		It Will Automatically Inference/Deduce From operateOnNumbers Definition
    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } )
    println(resultReturned)

   
    // Operator :: Will Get Reference
    //		Int::plus Reference To plus Function Defined For Int Type
    resultReturned = operateOnNumbers(4, 2, operation = Int::plus)
    println(resultReturned)

    // Following Lambdas Definitions Are Equivalent
    resultReturned = operateOnNumbers( 4, 2, { a, b -> a + b } ) 
    println(resultReturned)
    
    // Trailing Lambda
    // 		Lambda Is Last Argument In Function
    // 		Than It Can Be Written Outide of Paranthesis ()
    resultReturned = operateOnNumbers(4, 2) { a, b -> a + b }
    println(resultReturned)
    
    // Restructured Above Code Can Be Written As Follows With Trailing Lambda
    resultReturned = operateOnNumbers(4, 2) { 
    	a, b -> a + b 
    }
    println(resultReturned)
}

//______________________________________________________________

// var something = 10

// class DummyClass {
// }

fun String.filter( predicate: (Char) -> Boolean ) : String {
	val construtString = StringBuilder()

	for( index in 0 until length ) {
		val element = this.get(index)

		if ( predicate( element )) construtString.append( element )
	}

	return construtString.toString()
}

fun playWithFilterExtension() {
	val something = "abc123def8989ABCmmm"

	val choice = { character: Char -> character in 'a'..'z'  }

	val result = something.filter( choice  )
	println( result )
}



//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithCalculatorAgain")
	playWithCalculatorAgain()

	println("\nFunction: playWithLambdas")
	playWithLambdas()

	println("\nFunction: playWithLambdasAgain")
	playWithLambdasAgain()

	println("\nFunction: playWithFilterExtension")
	playWithFilterExtension()

	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

