

interface Clickable {
    fun click()
    fun showOff(click: Boolean) = println("Clickable: showOff Called...")
}

interface Focusable {
    fun setFocus()
    fun showOff(click: Boolean) = println("Clickable: showOff Called...")
}

class ButtonBetter : Clickable, Focusable {
    override fun click() = println("ButtonBetter: click Called...")
    override fun setFocus() = println("ButtonBetter: setFocus Called...")
    fun doMagic() = println("ButtonBetter: doMagic Called...")
    
    //override fun showOff(click: Boolean) = println("Clickable: showOff Called...")
}

fun main()  {
    val button = ButtonBetter()
    button.click()
    button.setFocus()
    super<Clickable>.showOff(click = true)
    // super<Focusable>.showOff(click = true)
    //button.showOff(click = true)

}

