
package learnKotlin

//___________________________________________________________________

// class Spiderman {
// 	fun fly() 		= println("Fly Like Spiderman!")
// 	fun saveWorld() = println("Save World Like Spiderman!")
// }

// class Human {
// 	fun fly() 		= println("Fly Like Human!")
// 	fun saveWorld() = println("Save World Like Human!")
// }

//___________________________________________________________________

// interface Create Abstract Type

// Superpower Abstract Type
//		Operation = { fly, saveWorld }
//		Range 	  = ϕ Set
interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman: Superpower {
	override fun fly() 		 = println("Fly Like Spiderman!")
	override fun saveWorld() = println("Save World Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 		 = println("Fly Like Superman!")
	override fun saveWorld() = println("Save World Like Superman!")
}

open class Heman {
	open fun fly() 		 = println("Fly Like Heman!")
	open fun saveWorld() = println("Save World Like Heman!")
}

class Wonderwoman : Superpower {
	override fun fly() 		 = println("Fly Like Wonderwoman!")
	override fun saveWorld() = println("Save World Like Wonderwoman!")	
}

// Using Mechanism : Inheritance
// class Human : Spiderman() {
// class Human : Superman() {
class Human : Heman () {
	override fun fly() 			{ super.fly() }
	override fun saveWorld() 	{ super.saveWorld() }
}

// COMPOSITION TO EQUIVALENT TO INHERITANCE
// Using Mechanism : Composition
class HumanBetter {
	// var power = Spiderman()
	// var power = Superman()
	var power = Heman()
	fun fly() 			{ power.fly() }
	fun saveWorld() 	{ power.saveWorld() }
}


// DESIGN PRINCIPLE
//		Design Towards Abstract Types Rather Than Concrete Types
//		Design Towards Interfaces Rather Than Concrete Classes

// DESIGN PRACTICE
//		PREFER COMPOSIITON OVER INHERITANCE

// COMPOSITION TO EQUIVALENT TO INHERITANCE
// Using Mechanism : Composition

// DEFINITION DRIVEN DESIGN
//		Some Invariant Code Block: C
//			Derivative Of C w.r.t. Time Is Zero
//		Hence Invariant Code C

// Invariant Code: HumanBest Definiton

class HumanBest {
	var power: Superpower? = null
	fun fly() 			{ power?.fly() }
	fun saveWorld() 	{ power?.saveWorld() }
}

fun playWithHuman() {
	val h = Human()
	h.fly()
	h.saveWorld()

	val hb = HumanBetter()
	hb.fly()
	hb.saveWorld()

	println("\n Best Human...")
	val hh = HumanBest()
	// error: type mismatch: inferred type is Superman but Superpower? was expected
	hh.power = Superman()
	hh.fly()
	hh.saveWorld()

	hh.power = Spiderman()
	hh.fly()
	hh.saveWorld()

	hh.power = Wonderwoman()
	hh.fly()
	hh.saveWorld()
}

//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________
//___________________________________________________________________

fun main() {
	println("\nFunction: playWithHuman")
	playWithHuman()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

