
package learnKotlin

/*
kotlinc KotlinClassesMore.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

//______________________________________________________________

data class Grade( val letter: Char, val points: Double, val credits: Double )

///			Primary Constructor
// Here constructor Is Keyword Is Optional
open class Person constructor( var firstName: String, var lastName: String = "" ) {
	// val fullName = "$firstName $lastName"
	fun fullName() = "$firstName $lastName"
}

open class Student(
	// var firstName: String, 
	// var lastName: String, 	
	firstName: String, // Not Redefining Properties Coming From Parent Class
	lastName: String, 
	var grades: MutableList<Grade> = mutableListOf<Grade>()
): Person( firstName, lastName ) {
// ): Person( ) { //  error: no value passed for parameter 'firstName

	open fun recordGrades( grade: Grade ) {
		grades.add( grade )
	}
}

fun playWithClassesAndObjects() {
	val gabbar = Person( firstName = "Gabbar", lastName = "Singh" )
	val alice = Student( firstName = "Alice", lastName = "Carol" )

	println( gabbar.fullName() )
	println( alice.fullName() )

	val history = Grade( letter = 'B', points = 9.0, credits = 3.0 )
	alice.recordGrades( history )
}

//______________________________________________________________
// OVERRIDING PROPERTY

open class BandMember( firstName: String, lastName: String ) : Student(firstName, lastName) {
	// Property Have 3 Things Associated With It: 
	//		1. Member Variable
	//		2. Getter
	//		3. Setter
	// error: 'minimumPracticeTime' in 'BandMember' is final and cannot be overridden
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class TablaPlayer( firstName: String, lastName: String ) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return super.minimumPracticeTime * 2 }
}

fun playWithTypeChecks() {
	val zakirHusaain: Person = TablaPlayer( firstName = "Zakir", lastName = "Husain" )
	var classMonitor = Student( firstName = "Visawnath", lastName = "Anand" )

	println( zakirHusaain.fullName() )
	println( classMonitor.fullName() )

	println( zakirHusaain is TablaPlayer )
	println( zakirHusaain is BandMember )
	println( zakirHusaain is Student )
	println( zakirHusaain is Person )

	println( classMonitor is TablaPlayer )
	println( classMonitor is BandMember )
	println( classMonitor is Student )
	println( classMonitor is Person )

	// println( zakirHusaain.minimumPracticeTime )
	println( (zakirHusaain as BandMember).minimumPracticeTime )
}


//______________________________________________________________
// FUNCTION OVERLOADING

// Polymorphism: Taking Multiple Forms
// How To Achieve Polymorphism Using Mechanism
// What Is Polymorphism?


// DEFINITION DRIVEN DESIGN
//		Some Code Block: C
//			Derivative Of C w.r.t. Time Is Zero
//		Hence Invariant Code C

// Mechanism: Function Overloading
//		C = Function Name
fun afterClassroomActivity( student: Student ) : String {
	return "Goes Home!"
}

fun afterClassroomActivity( student: BandMember ) : String {
	return "Goes To Practice!!!"
}


fun playWithAfterClassroomActivityFunctions() {
	val zakirHusaain = TablaPlayer( firstName = "Zakir", lastName = "Husain" )
	val gabbar = Student( firstName = "Gabbar ", lastName = "Singh" )

	println( afterClassroomActivity( zakirHusaain ) )
	println( afterClassroomActivity( gabbar ))
}


// POLYMORPHISM DESIGN PRACTICES

// Polymorphish Mechanisms Preference Order
//  1. Function With Default Arguments
//			Hence Prefer Constructors With Default Arguments Rather Than Overloading Constructor
//  2. Higher Order Functions
//			Passing and/or Returning Behvaiour From Behvaiour
//  3. Class/Type Is Polymophic
//	4. Function Overloding

//______________________________________________________________

class Athlete( firstName: String, lastName: String = "" ) : Student( firstName, lastName ) {
	val failedClasses = mutableListOf<Grade>()

	override fun recordGrades( grade: Grade ) {
		super.recordGrades(grade)

		if ( grade.letter == 'F' ) {
			failedClasses.add( grade )
		}
	}

	val isEligible: Boolean
		get() = failedClasses.size < 3
}

fun playWithAthelete() {
	val gabbar = Athlete( firstName = "Gabbar", lastName = "Singh" )

	val history = Grade( letter = 'B', points = 9.0, credits = 3.0 )
	val shooting = Grade( letter = 'A', points = 10.0, credits = 4.0 )
	val looting = Grade( letter = 'B', points = 9.0, credits = 3.0 )

	gabbar.recordGrades( history )
	gabbar.recordGrades( shooting )
	gabbar.recordGrades( looting )

	// Some Single Line Logic Can Be Written In prinln String Interpolation Using { }
	println("${gabbar.fullName() } is ${if (gabbar.isEligible) "Eligible" else "InEligible"}" )
}

//______________________________________________________________

interface DummyInterface {
	fun dummyFunction()
}


// Abstract Class
//		Having Atleast One Abstract Method
//			Abstract Method Have Only Signature
abstract class Mammal( val birthDate: String ) {
	abstract fun consumeFood()
	abstract fun doWork()
	fun doMagic() = println("Doing Magic")
}

// In Case Child Class Doesn't Provide Implementation Of Atleast One Abstract Method
//		Than Either Class Should Be Abstract Or Provide Implementation
// abstract class Human(birthDate: String) : Mammal( birthDate ) {

// Concrete Classes
//		Which Are Not Abstract
//		i.e. Which Provides Implementations For All Abstract Functions

class Human(birthDate: String) : Mammal( birthDate ) {
	override fun consumeFood() {
		println("Consuming Food....")
	}

	override fun doWork() {
		println("Do Work!!!")
	}

	fun createBirthCertificate() {
		println("Birth Certificate Generated With Date Of Birth: $birthDate")
	}
}

fun playWithMammels() {
 // error: cannot create an instance of an abstract class
 // error: interface DummyInterface does not have constructors
	// val mammel = Mammal("01/01/1955")
	// val dummy = DummyInterface()

	val gabbar = Human( "01/01/1960")
	gabbar.createBirthCertificate()

	gabbar.consumeFood()
	gabbar.doWork()
	gabbar.doMagic()
}

// DESIGN PRACTICE
//		1. Always Prefer Interfaces Over Abstract Classes
//		2. Always Prefer Abstast Classes Over Concrete Classes
//		3. Concrete Classes Are Last In Design 

//______________________________________________________________

// SECONDARY CONSTRUCTORS
// Constructor Overloading!!!

// CONSTRUCTOR DESIGN CHOICES

	//	Either You Define Default Construtor
	//		AND/OR
	//	Design Constructor Delegation
	//		Using this And/Or super
	//		PreCondition: All Properties Coming From Parent Class Should Be Initialised
	//			By Delegating to Parent Class Constructor


// CONSTRUCTOR DESIGN PRACICES
//		Always Prefer Primary Constructor With Default Arguments
//				You Will Maintain Only Constructor
//				You Can Prove Constructor Initialing Object Fully
//				Rather Than Overloading Use Default Arguments
//					Compulsary Arguments Should Come Before Default Arguments

//		For Constructor Overloading Practice
//				Every Class In Hierarcy Should Have Full Constructor
///					Full Constructor Initialises All The Properties
//				All Other Constructors In Same Class
//					Should Call Full Constructor Within Class
//				All Full Constructors Within Class Should Call Parent Class Full Constructor

// DESIGN PRINCIPLE
//		Object Must Follow Relflexive Law
//			Reflexive Law: For anny non-null reference value x, x.equals(x) should return true.

open class Shape {
	var size: Int
	var color: String

	// DESIGN 01 
	// constructor() {
	// 		this.size 	= 0
	// 		this.color 	= "Unknown"
	// }

	// constructor( size: Int ) {

	// DESIGN 04 :BEST DESIGN
	constructor( size: Int ) : this( size, "Unknown" ) {	
		// this.size = size
		// this.color = "Unknown"
	}

	constructor( size: Int, color: String ) { // FULL CONSTRUCTOR
		this.size = size
		this.color = color
	}

	override fun toString() = "Circle(size=$size, color=$color)"
}

class Circle : Shape {
	// DESIGN 00
	// constructor( size: Int ) {

	// DESIGN 02
	// constructor( size: Int ) : super( size ) {

	// DESIGN 03
	// constructor( size: Int ) : this( size, color ) {

	// DESIGN 04 :BEST DESIGN
	constructor( size: Int ) : this( size, "Unknown" ) {	
		// this.size = size
		// this.color = "Unknown"
	}

	// DESIGN 00
	// constructor( size: Int, color: String ) {

	// DESIGN 02
	// constructor( size: Int, color: String ) : super( size, color ) {

	// DESIGN 03
	// constructor( size: Int, color: String ) : this( size ) {

	// DESIGN 04 :BEST DESIGN
	constructor( size: Int, color: String ) : super( size, color ) { // FULL CONSTRUCTOR
		// this.size = size
		// this.color = color
	}

	override fun toString() = "Circle(size=$size, color=$color)"
}

// KotlinClassesMore.kt:242:2: 
// KotlinClassesMore.kt:247:2:
// error: explicit 'this' or 'super' call is required. 
// There is no constructor in superclass that can be called without arguments

// error: there's a cycle in the delegation calls chain
// 		constructor( size: Int ) : this( size, color ) {
// error: there's a cycle in the delegation calls chain
// 		constructor( size: Int, color: String ) : this( size ) {

fun playWithConstructors() {
	val shape1 = Shape( 99 )
	val shape2 = Shape( 99, "Red" )

	println( shape1 )
	println( shape2 )

	val circle1 = Circle( 111 )
	val circle2 = Circle( 111, "Blue" )

	println( circle1 )
	println( circle2 )
}

//______________________________________________________________
// VISIBILITUY MODIFIERS

data class Privilege( val id : Int, val name: String )

open class User( val username: String, private val id: String, protected var age: Int )

class PrivilegedUser(username: String, id: String, age: Int) : User( username, id, age ) {
	private val privileges = mutableListOf<Privilege>()

	fun addPrivilege( privilege: Privilege ) {
		privileges.add( privilege )
	}

	fun hasPrivilege( id: Int ): Boolean {
		return privileges.map( { it.id } ).contains(id)
	}

	fun about(): String = "$username, $age"
}

fun playWithVisibilityModifiers() {
	val gabbar = PrivilegedUser( username = "Gabbar Singh", id = "420", age = 30 )
	val privilege = Privilege( 1, "Uncatchable!")
	gabbar.addPrivilege( privilege )
	println( gabbar.about() )
}


// Kotlin Visibility Modifiers
// ___________________________________________________________________

// Modifiers 			|  	Class Member 		| Top-Level Member
// ___________________________________________________________________
// public (default) 	| Visible everywhere 	| Visible everywhere 
// internal 			| Visible in a module   | Visible in a module
// protected 			| Visiable In SubClasses| NOT APPLICABLE
// private  			| Visible In A Class 	| Visible In File
// ___________________________________________________________________


//______________________________________________________________

class UserAgain( val id: Int, val name: String, val address: String )


fun UserAgain.save( ) { // Enclosing Context/ Outside Function
	var something = "Ding Dong"
	val user = this
	// Localisation: Encapsulation
	//		Improve Readability
	//		Help In Refactoring

	// Local Class
	//		Class Defined Inside Functions
	class Human( val id: Int, val firstname: String, val lastname:String ) {
		val fullname: String 
			get() = "$firstname $lastname"
	}

	val gabbar = Human( 420, "Gabbar", "Singh")
	println( gabbar.fullname ) 

	// Local Function : Written For Very Specific Validation
	//		Inside Function Captures The Context From Outside Function
	//		Enclosed Context Captures The Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context/ Inside Function
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User : Empty $fieldName")
		}

		println( something )

		val basanti = Human(100, "Basanti", "Dancer")
		println( basanti.fullname )
	}

	validate( this.name, "Name" )
	validate( this.address, "Address" )

	// Logic For Saving User...
	println("Saving User : ${user.id}")
}

fun playWithSaveExtension() {
	val gabbar = UserAgain( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = UserAgain( 100, "Basanti", "Ramgarh" )

	gabbar.save()
	basanti.save()
}

//______________________________________________________________

// Definining Class Inside Class
//		In Java
//			By Default Classes Defined Inside Class Are Inner Classes

//		In Kotlin
//			By Default Classes Defined Inside Class Are Nested Classes

class Car1(val carName: String) { // Enclosing Class Context
	var something = "Hello Intuit!"

	fun doSomething() { // Enclosed Function Context 
		// Can Access Enclosing Class Context
		println( "$something :: $carName" )
	}

	// Definining Class Inside Class
	//	 	In Kotlin By Default Inside Classes Are Nested Classes
	//		Nested Classes Can't Access Enclosing Class Context
	class Engine(val engineName: String ) { // Enclosed Class Context
		override fun toString(): String {
			// error: unresolved reference: something
			// println( something )
			// error: unresolved reference: carName
			// return "Engine(engineName=$engineName) Inside Car1(carName=$carName)"

			return "Engine(engineName=$engineName)"
		}
	}

	override fun toString() = "Car1(carName=$carName)"
}


class Car2(val carName: String) { // Enclosing Class Context
	var something = "Hello Intuit!"

	fun doSomething() { // Enclosed Function Context 
		// Can Access Enclosing Class Context
		println( something )
		println( "$something :: $carName" )
	}

	// Definining Class Inside Class
	//	 	In Kotlin By Default Inside Classes Are Nested Classes
	//		Nested Classes CANNOT Access Enclosing Class Context

	//		To Make Class Inside Class Inner Class Use inner Keyword
	//		Innner Classes CAN Access Enclosing Class Context
	inner class Engine(val engineName: String ) { // Enclosed Class Context
		override fun toString(): String {
			// return "Engine(engineName=$engineName)"
			// error: unresolved reference: something
			println( something )
			// error: unresolved reference: carName
			return "Engine(engineName=$engineName) Inside Car1(carName=$carName)"
		}
	}

	override fun toString() = "Car1(carName=$carName)"
}


fun playWithNestedAndInnerClasses() {
	val mazda1 = Car1("Mazda")
	val mazdaEngine1 = Car1.Engine("Rotary")
	println( mazda1 )
	println( mazdaEngine1 )

	val mazda2 = Car2("Mazda")
	val mazdaEngine2 = mazda2.Engine("Rotary")
	println( mazda2 )
	println( mazdaEngine2 )
}

//______________________________________________________________

// WHAT ARE THE USE CASES OF static IN JAVA?
// 1. Singleton Classes : In Kotlin Using object
// 2. Factory Methods : Methods Creating Objects: In Kotlin Using companion Objects

// ALL OTHER USE CASES OF static HAVE BETTER ALTERNATIVES
// 3. Utility Classes
// 4. Sharing State Across Objects
// 5. For Creating Constants 
// 6.

//______________________________________________________________

class SomeClass {
	companion object {
		fun doMagic() {
			println("Doing Magic!!!")
		}

		fun doSomething() {
			println("Doing Something....")
		}
	}
}

fun playWithCompanionObject() {
	// doMagic Method Accessed Using Class Name
	SomeClass.doMagic()
	SomeClass.doSomething()
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________


fun main() {
	println("\nFunction : playWithClassesAndObjects")
	playWithClassesAndObjects()

	println("\nFunction : playWithTypeChecks")
	playWithTypeChecks()

	println("\nFunction : playWithAfterClassroomActivityFunctions")
	playWithAfterClassroomActivityFunctions()

	println("\nFunction : playWithAthelete")
	playWithAthelete()

	println("\nFunction : playWithMammels")
	playWithMammels()

	println("\nFunction : playWithConstructors")
	playWithConstructors()

	println("\nFunction : playWithSaveExtension")
	playWithSaveExtension()

	println("\nFunction : playWithNestedAndInnerClasses")
	playWithNestedAndInnerClasses()

	println("\nFunction : playWithCompanionObject")
	playWithCompanionObject()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

