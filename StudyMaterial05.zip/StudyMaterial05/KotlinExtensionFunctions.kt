
fun String.second(): Char {
    if (isEmpty()) throw NoSuchElementException("Char sequence is empty.")
    if (length < 2) throw NoSuchElementException("Char sequence length is less than 2.")
    return this[1]
}



// Kotlin Byte Code Decompiled To Java

public final class KotlinExtensionFunctionsKt {

   public static final char second(@NotNull String $receiver) {
      Intrinsics.checkParameterIsNotNull($receiver, "$receiver");
      CharSequence var1 = (CharSequence)$receiver;
      if (var1.length() == 0) {
         throw (Throwable)(new NoSuchElementException("Char sequence is empty."));
      } else if ($receiver.length() < 2) {
         throw (Throwable)(new NoSuchElementException("Char sequence length is less than 2."));
      } else {
         return $receiver.charAt(1);
      }
   }
}

