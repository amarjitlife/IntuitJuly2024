
package learnKotlin

/*
Compiling Kotlin Code
kotlinc KotlinClasses.kt -include-runtime -d classes.jar

Running Compiled Jar File
java -jar classes.jar
*/

//______________________________________________________________

// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// DESIGN DECISION
//		Best Practices Are Becoming Part of Langauge Design

// BEST PRACTICE
//		 Classes Must Be FINAL If Not Meant To Be Inherited

// In Kotlin
//		 By Default Classes Are Final
//				Final Classes Are Not Inheritable
//		 By Default Members Are Final
//				Final Members Cann't Be Overridden

// In Java
//		 By Default Classes Are Open
//				Open Classes Are Inheritable
//		 By Default Members Are Open
//				Open Members Can Be Overridden

// error: this type is final, so it cannot be inherited from
// error: 'click' in 'View' is final and cannot be overridden
open class View {
	open fun click() = println("View: click Called...") 
}

// Inheritance Button Is Subclass and View Is Parent/Superclass
class Button : View() {
	override fun click() 	= println("Button: click Called...")
	fun magic() 			= println("Button: magic Called...")
}


fun View.showOff() 		= println("View : showOff Called...")
fun Button.showOff() 	= println("Button: showOff Called...")

fun playWithClassesInheritance() {
	// 1. RHS Inferred Type Is View
	// 2. LHS Binded Type Will Be Inferred Type
	val vo = View() // vo Is View Type
	vo.click()
	vo.showOff() // vo Is View Type Hence showOff Will Map To View Type showOff

	val bo = Button() // bo Is Button
	bo.click()
	bo.magic()
	bo.showOff() // bo Is Button Type Hence showOff Will Map To Button Type showOff

	// Setting Perceptive
	// Seeing Sub Type Object w.r.t Super Type i.e. Parent Class
	val viewAgain : View = Button() // viewAgain Type Is View
	viewAgain.click()
	// error: unresolved reference: magic
	// viewAgain.magic()

	// Extension Functions Doesn't Participates In Overriding
	viewAgain.showOff() // viewAgain Is View Type Hence showOff Will Map To View Type showOff

	// Resetting Percpetive To Sub Type i.e.. Child Class
	val buttonBack: Button = viewAgain as Button // buttonBack is Button Type
	buttonBack.magic()
	buttonBack.showOff() // buttonBack Is Button Type Hence showOff Will Map To Button Type showOff
}

// Function : playWithClassesInheritance
// View: click Called...
// View : showOff Called...
// Button: click Called...
// Button: magic Called...
// Button: showOff Called...
// Button: click Called...
// View : showOff Called...
// Button: magic Called...
// Button: showOff Called...

//______________________________________________________________

open class Parent {
	open fun doStudy() 		= println("Parent: Study Well")
	open fun doEarn() 	 	= println("Parent: Earn Well")
	fun getMarried() 		= println("Parent: Get Married")
}

class Child : Parent() {
	override fun doStudy() = println("Child: Studied Well")
	override fun doEarn()  = println("Child: Earned Well")
	fun playCricket() 	   = println("Child: Play Cricket!")
	fun someSmoking() 	   = println("Have Some Exploration In Life!!!")
}

fun playWithParentAndChild() {
	// DESIGN PRINCIPLE
	//			An Object Can Have Multiple Types
	//			Gives Choices To See Object As Per Different Type Perceptives
	val someKid: Parent = Child()

	someKid.doStudy()
	someKid.doEarn()
	someKid.getMarried()
	// parent.playCricket()
	// parent.someSmoking()

	// //error: type mismatch: inferred type is Parent but Child was expected
	// val friend: Child = someKid
	// friend.playCricket()
	// friend.someSmoking()

	val friendAgain = someKid as Child
	friendAgain.playCricket()
	friendAgain.someSmoking()

	someKid.playCricket()
	someKid.someSmoking()
}

//______________________________________________________________

// In Kotlin Interfaces
//		By Default
//		Interfaces Are Open 
//		All Members Are Also Open
//		Member Functions Can Have Default Implementation
//			NOTE: Use It Only In Rarest Rare Cases
//				  When Really Some Common Functionlity Is Applicable Everywhere

// Interfaces Defines What It Is
//		i.e. What To Do?
interface Clickable {
	fun click()
	// showOff Is Instance Member Function With Default Implementation
	// fun showOff( click: Boolean ) = println( "Clickable : Default showOff Called...")
	fun showOff() = println( "Clickable : Default showOff Called...")
}

interface Focusable {
	fun setFocus()  	
	fun showOff( click: Boolean ) = println( "Focusable : Default showOff Called...")
}

// Class ButtonBetter Implementing Interfaces Clickable and Focusable
// 		Concrete Classes Should Answer Following Questions
//			How, When, Which, Where, Way

// error: class 'ButtonBetter' must override public open fun showOff(click: Boolean): Unit 
//			defined in learnKotlin.Clickable 
// because it inherits multiple interface methods of it
class ButtonBetter : Clickable, Focusable {
	override fun click() 	= println("ButtonBetter: click Called...")
	override fun setFocus() = println("ButtonBetter: setFocus Called...")
	fun doMagic() = println("ButtonBetter: doMagic Called...")

/*
	override fun showOff( click: Boolean ) {
		println("ButtonBetter: showOff Called...")
		// error: many supertypes available, please specify the one you mean 
		//	in angle brackets, e.g. 'super<Foo>'
		// super.showOff(click = true)

		// Business Logic
		if ( click ) {
			super<Clickable>.showOff( click ) 
		} else {
			super<Focusable>.showOff( click )
		}	
	}
*/

}

fun playWithButtonBetter() {
	val button = ButtonBetter()
	button.click()
	button.setFocus()
	button.showOff( click = true )

	button.doMagic()
}

//______________________________________________________________

enum class Color(val r: Int, val g: Int, val b: Int ) {
	RED( 255, 0, 0 ), GREEN( 0, 255, 0 ), BLUE( 0, 0, 255 ),
	ORANGE( 200, 200, 2000 ), YELLOW( 100, 100, 100 ),
	UNKOWN( 0, 0, 0 )
}

fun getColorName( color: Color ) : String {
	return when( color ) {
		// Type Safe Code
		Color.RED 		-> "Red Color"
		Color.GREEN 	-> "Green Color"
		Color.BLUE 		-> "Blue Color"
		Color.ORANGE 	-> "Orange Color"
		Color.YELLOW 	-> "Yellow Color"
		Color.UNKOWN 	-> "Unknown Color"
	}
}

fun getColorNameAgain( color: Color ) : String = when( color ) {
	// Type Unsafe Code
	Color.RED 	-> "Red Color"
	Color.GREEN -> "Green Color"
	Color.BLUE 	-> "Blue Color"

	// Black Hole
	else 		-> "Unknown Color" // Default Branch
// 	error: 'when' expression must be exhaustive, 
//	add necessary 'ORANGE' branch or 'else' branch instead
}


// error: the integer literal does not conform to the expected type String
// fun getColorNameOnceAgain( color: Color ): String = when( color ) {

// Following Two Lines of Code Are Equivalent
// fun getColorNameOnceAgain( color: Color ): Any = when( color ) {

fun getColorNameOnceAgain( color: Color ) = when( color ) {
	// when Is A Type Safe Expression
	Color.RED 		-> "Red Color"
	Color.GREEN 	-> "Green Color"
	Color.BLUE 		-> "Blue Color"
	Color.ORANGE 	-> "Orange Color"
	Color.YELLOW 	-> "Yellow Color"
	// Color.YELLOW 	-> 99
	Color.UNKOWN 	-> "Unknown Color"
}


fun getColorNature( color: Color ) : String {
	return when( color ) {
		Color.RED, Color.ORANGE 	-> "Warm Color"
		Color.GREEN 				-> "Cold Color"
		Color.BLUE, Color.YELLOW 	-> "Neutral Color"
		Color.UNKOWN 				-> "Unknown Color"
	}
}

fun playWithColors() {
	println( getColorName( Color.RED ))
	println( getColorName( Color.GREEN ))
	println( getColorName( Color.BLUE ))

	println( getColorNameAgain( Color.RED ))
	println( getColorNameAgain( Color.GREEN ))
	println( getColorNameAgain( Color.BLUE ))

	println( getColorNameOnceAgain( Color.RED ))
	println( getColorNameOnceAgain( Color.GREEN ))
	println( getColorNameOnceAgain( Color.BLUE ))

	println( getColorNature( Color.RED ))
	println( getColorNature( Color.GREEN ))
	println( getColorNature( Color.BLUE ))
}

//______________________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr) : Expr

fun evaluate( e: Expr ) : Int = when ( e ) {
	is Num -> e.value
	is Sum -> evaluate( e.left ) + evaluate( e.right )
	else   -> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvaluate() {
	// 10 + 20
	println( evaluate( Sum( Num(10), Num(20) ) ))
	// (10 + 20 ) + 200
	println( evaluate( Sum( Sum( Num(10), Num(20) ), Num(200) ) ) )
}

//______________________________________________________________


sealed class Expression {
	class Num( val value: Int ) : Expression()
	class Sum( val left: Expression, val right: Expression ) : Expression()
}

fun evaluateAgain( e: Expression ) : Int = when ( e ) {
	is Expression.Num -> e.value
	is Expression.Sum -> evaluateAgain( e.left ) + evaluateAgain( e.right )

	// warning: 'when' is exhaustive so 'else' is redundant here
	// Dead Code - Unreachable Code, Hence It Will Not Execute
	// else   -> throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvaluateAgain() {
	// 10 + 20
	println( evaluateAgain( Expression.Sum( Expression.Num(10), Expression.Num(20) ) ))
	// (10 + 20 ) + 200
	println( evaluateAgain( Expression.Sum( Expression.Sum( Expression.Num(10), Expression.Num(20) )
		, Expression.Num(200) ) ) )
}

//______________________________________________________________

// error: 'toString' hides member of supertype 'Any' and needs 'override' modifier

class Client( val name: String, val postalCode: Int )  {
	override fun toString() = "Client(name=$name, postalCode=$postalCode)"

	override fun equals( other: Any? ) : Boolean {
		if ( other == null || other !is Client ) return false
		return name == other.name && postalCode == other.postalCode
	}
}


fun playWithClient() {
	val client = Client("Alice", 99999 )
	println( client.name )
	println( client.postalCode )
	println( client )

	val client1 = Client("Alice", 99999 )
	val client2 = Client("Alice", 99999 )

	println( client1 )
	println( client2 )

	// By Default Equality Operator Does Reference Comparison
	// On Overloading equal Function Than equal Function
	println( client1 == client2 ) // client1.equals( client2 )
}	


//______________________________________________________________
// DATA CLASS
//	 Compiler Will Generate Following Methods Code
//			1. toString Method Code Usign All Properties
//			2. equals() Method Code Based On Equality Of All Properties
//			3. hashCode() Method Code Based On All Properties
//			4. copy Mehtod Code To Dupliate Object

data class Client1( val name: String, val postalCode: Int )  

// {
// 	override fun toString() = "Client(name=$name, postalCode=$postalCode)"

// 	override fun equals( other: Any? ) : Boolean {
// 		if ( other == null || other !is Client ) return false
// 		return name == other.name && postalCode == other.postalCode
// 	}
//	
//	Whenever You Override equals() Method. You Should Override hashCode() Method
// }


fun playWithClient1() {
	val client = Client1("Alice", 99999 )
	println( client.name )
	println( client.postalCode )
	println( client )

	val client1 = Client1("Alice", 99999 )
	val client2 = Client1("Alice", 99999 )

	println( client1 )
	println( client2 )

	// By Default Equality Operator Does Reference Comparison
	// On Overloading equal Function Than equal Function
	println( client1 == client2 ) // client1.equals( client2 )
}	

// Function : playWithClient1
// Alice
// 99999
// Client1(name=Alice, postalCode=99999)
// Client1(name=Alice, postalCode=99999)
// Client1(name=Alice, postalCode=99999)
// true

//______________________________________________________________

// DESIGN PRINCIPLES
//		Most Common Design Patterns Are Becoming Part The Language

// OBJECT CLASSES
//		Singleton Classes i.e. Can Have Only One Instance Possible.

// This Single Instance Name Will Be Same As Class Name
object India {
	fun name() : String {
		return "Hindustan!"
	}
}

fun playWithSingleton() {

	val data = India.name()
	println( data )
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction : playWithClassesInheritance")
	playWithClassesInheritance()

	println("\nFunction : playWithParentAndChild")
	playWithParentAndChild()

	println("\nFunction : playWithButtonBetter")
	playWithButtonBetter()

	println("\nFunction : playWithEvaluate")
	playWithEvaluate()

	println("\nFunction : playWithEvaluateAgain")
	playWithEvaluateAgain()

	println("\nFunction : playWithClient")
	playWithClient()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithSingleton")
	playWithSingleton()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

