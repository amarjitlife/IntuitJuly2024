

fun login(username: String, password: String) : Boolean {
    var something = 1

    fun validateInput(input: String){
        something++
        if (input.isEmpty()) {
            throw IllegalArgumentException("Must not be empty")
        }
    }

    validateInput(username)
    validateInput(password)

    return true
}


// Decompiled Kotlin Byte Code Code

public class KotlinLocalFunctionKt {

   public static final boolean login(@NotNull String username, @NotNull String password) {
      Intrinsics.checkParameterIsNotNull(username, "username");
      Intrinsics.checkParameterIsNotNull(password, "password");
      final IntRef something = new IntRef();
      something.element = 1;

      <undefinedtype> validateInput$ = new Function1() {
         // $FF: synthetic method
         // $FF: bridge method
         public Object invoke(Object var1) {
            this.invoke((String)var1);
            return Unit.INSTANCE;
         }

         public final void invoke(@NotNull String input) {
            Intrinsics.checkParameterIsNotNull(input, "input");
            int var2 = something.element++;
            CharSequence var3 = (CharSequence)input;
            if (var3.length() == 0) {
               throw (Throwable)(new IllegalArgumentException("Must not be empty"));
            }
         }
      };

      validateInput$.invoke(username);
      validateInput$.invoke(password);
      
      return true;
   }
}

