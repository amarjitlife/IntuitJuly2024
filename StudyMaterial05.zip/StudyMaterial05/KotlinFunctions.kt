

package learnKotlin

/*
Compiling Kotlin Code
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar

Running Compiled Jar File
java -jar functions.jar
*/

//______________________________________________________________

// Generics/Templates
//		It Is Code To Generate Code

// <T> It's Directive To Compiler That T Is Type Placeholder
// T Is Type Placeholder
//		T Will Be Substituted With Type

// Polymorphic Function
//		Compile Time Polymorphism
//		Mechanim: Generics
fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

// Compiler Will Generate Following Codes
/*
fun joinToString(
	collection: Collection<Integer>,
	separator: String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun joinToString(
	collection: Collection<String>,
	separator: String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}
*/

fun playWithJoinToString() {
	// 1. Type Inferrencing From RHS\
	// 2. Type Binding Happens On LHS
	val list = listOf( 10, 20, 30 ) // ArrayList<Integer>
	println( list.javaClass )

	// First Argument ArrayList<Integer> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With Integer
	println( joinToString( list, " ; ", " ( ", " ) " ))

	// First Argument ArrayList<String> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With String
	val names = listOf( "Ding", "Dong", "Ting", "Tong" ) // ArrayList<String>
	println( names.javaClass )
	println( joinToString( names, " :: ", " [[ ", " ]] " ))
}

//______________________________________________________________
// EXTENSION FUNCTIONS
//		MECHANISM TO ADD FUNCTIONALITY TO EXISITNG CLASSES/TYPES

fun lastChar( data: String ) = data.get( data.length -1 )

// Extension Function
//		lastCharacter Is An Extension Function On Type String
fun String.lastCharacter( ) = this.get( this.length - 1 )

fun playWithLastCharacter() {
	println( lastChar( "Kotlin") )

	val greeting = "Good Morning!"
	println( lastChar( greeting ) )

	println( "Kotlin".lastCharacter() )
	println( greeting.lastCharacter() )
}


//______________________________________________________________


fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}


fun playWithJoinToStringExtension() {
	// 1. Type Inferrencing From RHS\
	// 2. Type Binding Happens On LHS
	val list = listOf( 10, 20, 30 ) // ArrayList<Integer>
	println( list.javaClass )

	// First Argument ArrayList<Integer> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With Integer
	println( list.joinToStringExtension( " ; ", " ( ", " ) " ))

	// First Argument ArrayList<String> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With String
	val names = listOf( "Ding", "Dong", "Ting", "Tong" ) // ArrayList<String>
	println( names.javaClass )
	println( names.joinToStringExtension( " :: ", " [[ ", " ]] " ))
}

//______________________________________________________________
// Defaults Arugments

// Polymorphic Function
//		Mechanism: Using Default Arugments
//		Mechanism: Generics

// DEFINITION DRIVEN DESIGN
//		Some Invariant Code Feature: C
//			Derivative Of C w.r.t. Time Is Zero
//		Hence Invariant Code C

// Invariant Code: Function Signature i.e. Function Name, Arguments and Return Type
fun <T> Collection<T>.joinToStringExtensionDefaults(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
): String {
	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}


fun playWithJoinToStringExtensionDefaults() {
	// 1. Type Inferrencing From RHS\
	// 2. Type Binding Happens On LHS
	val list = listOf( 10, 20, 30 ) // ArrayList<Integer>
	println( list.javaClass )

	// First Argument ArrayList<Integer> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With Integer
	println( list.joinToStringExtensionDefaults( " ; ", " ( ", " ) " ))
	println( list.joinToStringExtensionDefaults( ) )
	println( list.joinToStringExtensionDefaults( " ; " ) )
	println( list.joinToStringExtensionDefaults( " ; ", " ( " ))
	println( list.joinToStringExtensionDefaults( " ; ", " ( ", " ) " ))


	// First Argument ArrayList<String> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With String
	val names = listOf( "Ding", "Dong", "Ting", "Tong" ) // ArrayList<String>
	println( names.javaClass )
	println( names.joinToStringExtensionDefaults( " :: ", " [[ ", " ]] " ))
	println( names.joinToStringExtensionDefaults( " :: " ) )
	println( names.joinToStringExtensionDefaults( " :: ", " [[ " ))
}

//______________________________________________________________

fun Collection<String>.join(
	separator: String = ", ",
	prefix : String = "",
	postfix: String = ""
) = joinToStringExtensionDefaults( separator, prefix, postfix )

fun playWithJoinExtension() {
	// 1. Type Inferrencing From RHS\
	// 2. Type Binding Happens On LHS
	val list = listOf( 10, 20, 30 ) // ArrayList<Integer>
	println( list.javaClass )

	// First Argument ArrayList<Integer> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With Integer
	// println( list.join( " ; ", " ( ", " ) " ))

	// First Argument ArrayList<String> 
	// First Argument In Denfintion : Collection<T>
	//		Hence Compiler Will Substite T With String
	val names = listOf( "Ding", "Dong", "Ting", "Tong" ) // ArrayList<String>
	println( names.javaClass )
	println( names.join( " :: ", " [[ ", " ]] " ))
	println( names.join( " :: " ) )
	println( names.join( " :: ", " [[ " ))
}

//______________________________________________________________

//  Immutable Extension Property On Type String
val String.lastChar: Char
	get() = get( length - 1)

//  Mutable Extension Property On Type StringBuilder
var StringBuilder.lastChar: Char
	get() {
		println("Getter Called...")
		return get( length - 1 )
	} 
	set( value: Char ) {
		println("Setter Called...")
		this.setCharAt( length - 1, value )

	}


fun playWithExtensionProperties() {
	var character = "Welcome To India!".lastChar
	println( character )

	character = "Ding Dong$#".lastChar
	println( character )

	var stringBuild = StringBuilder("Welcome To India!")
	println( stringBuild.lastChar )

	stringBuild = StringBuilder("Ding Dong$#")
	println( stringBuild.lastChar )
	stringBuild.lastChar = '$'
	println( stringBuild.toString() )
}

//______________________________________________________________
// LOCAL FUNCTIONS

fun moveTowardsZero( start: Int ) : Int {
	// Local Functions
	//		Functions Defined Inside Another Function
	fun moveForward( start: Int ) = start + 1
	fun moveBackward( start: Int ) : Int {
		return start - 1
	}

	return if ( start > 0 ) moveBackward( start ) else moveForward( start )
}

fun playWithLocalFunctions() {
	println( moveTowardsZero( 10 ) )
	println( moveTowardsZero( -10) )
}

//______________________________________________________________

// In Kotlin
//		By Default 
//			Return Type Of Function is Unit
//			And It Returns Unit Value Of Unit Type
// fun doSoemthing() {
fun doSoemthing(): Unit {
	println("How are you doing?")
}

fun playWithDoSomething() {
	doSoemthing()
}

//______________________________________________________________

class User( val id: Int, val name: String, val address: String )

fun saveUser( user: User ) {
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id} : Empty Name")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id} : Empty Address")
	}

	// Logic For Saving User...
	println("Saving User ${user.id}")
}

fun playWithSaveUser() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	saveUser( gabbar )
	saveUser( basanti )
}


//______________________________________________________________

// class User( val id: Int, val name: String, val address: String )

// DESIGN PRINCPLE
//		DRY : Dont' Repeat Yourself

fun saveUserAgain( user: User ) { // Enclosing Context/ Outside Function
	var something = "Ding Dong"
	// Localisation: Encapsulation
	//		Improve Readability
	//		Help In Refactoring

	// Local Function : Written For Very Specific Validation
	//		Inside Function Captures The Context From Outside Function
	//		Enclosed Context Captures The Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context/ Inside Function
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${user.id} : Empty $fieldName")
		}

		println( something )
	}

	validate( user.name, "Name" )
	validate( user.address, "Address" )

	// Logic For Saving User...
	println("Saving User ${user.id}")
}

fun playWithSaveUserAgain() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	saveUserAgain( gabbar )
	saveUserAgain( basanti )
}

//______________________________________________________________


fun User.save( ) { // Enclosing Context/ Outside Function
	var something = "Ding Dong"
	val user = this
	// Localisation: Encapsulation
	//		Improve Readability
	//		Help In Refactoring

	// Local Function : Written For Very Specific Validation
	//		Inside Function Captures The Context From Outside Function
	//		Enclosed Context Captures The Enclosing Context
	fun validate( value: String, fieldName: String ) { // Enclosed Context/ Inside Function
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User : Empty $fieldName")
		}

		println( something )
	}

	validate( this.name, "Name" )
	validate( this.address, "Address" )

	// Logic For Saving User...
	println("Saving User : ${user.id}")
}

fun playWithSaveExtension() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Ramgarh" )

	gabbar.save()
	basanti.save()
}

//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction: playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction: playWithJoinToStringExtensionDefaults")
	playWithJoinToStringExtensionDefaults()

	println("\nFunction: playWithJoinExtension")
	playWithJoinExtension()

	println("\nFunction: playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction: playWithLocalFunctions")
	playWithLocalFunctions()

	println("\nFunction: playWithDoSomething")
	playWithDoSomething()

	println("\nFunction: playWithSaveUser")
	playWithSaveUser()

	println("\nFunction: playWithSaveUserAgain")
	playWithSaveUserAgain()

	println("\nFunction: playWithSaveExtension")
	playWithSaveExtension()
	
	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

