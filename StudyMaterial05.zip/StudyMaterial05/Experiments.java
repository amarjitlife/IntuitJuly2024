
import java.io.Serializable; 

interface State extends Serializable {

}

interface View {
	public State getCurrentState();
	public void restoreState( State state );
}

class Button implements View {
	public class ButtonState implements State {

	}

	@Override
	public State getCurrentState() {
		return new ButtonState();
	}

	@Override 
	public void restoreState(State state) { 

	}
}

public class Experiments {

	public static void playWithButton() {
		Button button = new Button();
		button.getCurrentState();
		// button.restoreState();

	}

	public static void playWithNumbers() {
		// try {
		System.out.println(  1.0 / 0.0 );
		System.out.println( -1.0 / 0.0 );
		System.out.println(  0.0 / 0.0 );
		// } catch () {

		// }
		System.out.println(  1.0 / 0.0 == Double.POSITIVE_INFINITY);
		System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY);
		System.out.println(  0.0 / 0.0 == Double.NaN );

		// BEST PRACTICE
		System.out.println(  Double.isInfinite( 1.0 / 0.0 ) );
		System.out.println(  Double.isFinite( -1.0 / 0.0 )  );
		System.out.println(  Double.isNaN( 0.0 / 0.0)  );

		// System.out.println( 1 / 0 );		
		// System.out.println( );
		// System.out.println( );
	}

// Function : playWithNumbers
// Infinity
// -Infinity
// NaN
// true
// true
// false

	public static void main( String[] args) {
		System.out.println("\nFunction : playWithNumbers");
		playWithNumbers();

		System.out.println("\nFunction : playWithButton");
		playWithButton();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

