______________________________________________________________

DAY 01
______________________________________________________________

	Assingment 01: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment 02: Revise/Study Java
		Revise Classes and Interfaces Topics
		
______________________________________________________________

DAY 02
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter

	Assingment A3: Experimentation and Exploration
		1. Experiment Following Code In C/C++/Python/Kotlin/JS
			Reason The Output as well as Design Decisions In Each Language

		2. What Is Mathematical Definfitions And Which Language Implements What?

		public static void playWithNumbers() {
			// try {
			System.out.println(  1.0 / 0.0 );
			System.out.println( -1.0 / 0.0 );
			System.out.println(  0.0 / 0.0 );
			// } catch () {

			// }
			System.out.println(  1.0 / 0.0 == Double.POSITIVE_INFINITY);
			System.out.println( -1.0 / 0.0 == Double.NEGATIVE_INFINITY);
			System.out.println(  0.0 / 0.0 == Double.NaN );

			// BEST PRACTICE
			System.out.println(  Double.isInfinite( 1.0 / 0.0 ) );
			System.out.println(  Double.isFinite( -1.0 / 0.0 )  );
			System.out.println(  Double.isNaN( 0.0 / 0.0)  );

			// System.out.println( 1 / 0 );		
			// System.out.println( );
			// System.out.println( );
		}

______________________________________________________________

DAY 03
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Experimentation and Exploration
		Parent and Child Example Experiment In Java
		Experiment Higher Order Functions In Java
		Value Capture Experiment In Java

	Assingment A4: Inquistive and Brave Hearts! [ OPTIONAL ASSIGNMENT ]
		Reading Pointers and Arrays Chapter
		Reference: The C Programming Language, 2nd Edition

______________________________________________________________

DAY 04
______________________________________________________________

	Assingment A1: Practice and Experiment Kotlin Code
		Practice and Experiment Kotlin Code Done Till Now

	Assingment A2: Revise/Study Java
		Reference:
			Core Java for the Impatient 3rd Edition by Cay S. Horstmann (Author)
		Study Classes and Interfaces Chapter
		Higher Order Functions

	Assingment A3: Revise/Study Kotlin
		Reference:
			Kotlin in Action, Second Edition 2nd Edition
				by Sebastian Aigner (Author), Roman Elizarov (Author), 
				Svetlana Isakova (Author), & 1 more
			
			Chapter 01 To 04 [ INCLUSIVE ]
				Read and Experiment Kotlin Code
				Compare With Java Code Also

	Assingment A4: Experimentation and Exploration
		Parent and Child Example Experiment In Java
		Experiment Higher Order Functions In Java
		Value Capture Experiment In Java

	Assingment A5: Advance Reading and Experimentation Assignments
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
		Create Use Cases Where Equality and/or Hashcode Contract Violated

	Assingment A6: Inquistive and Brave Hearts! [ OPTIONAL ASSIGNMENT ]
		Reading Pointers and Arrays Chapter
		Reference: The C Programming Language, 2nd Edition

______________________________________________________________
______________________________________________________________
______________________________________________________________
______________________________________________________________
______________________________________________________________


