
package learnKolin

/*
Compiling Kotlin Code
kotlinc HelloWorld.kt -include-runtime -d hello.jar

Running Compiled Jar File
java -jar hello.jar
*/

//______________________________________________________________

fun main() {
	println("Hello World!!!");
}

//______________________________________________________________

// Kotlin Compiler Will Generate Following Java Code 
//		For Above One
// 		Because Of Java/Java Byte Specification

// public class HelloWorldKt {
// 		public static main(String[] args) {
// 			System.out.println("Hello World!!!");
// 		}
// }
//

//______________________________________________________________

