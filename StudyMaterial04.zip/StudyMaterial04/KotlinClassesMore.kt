
package learnKotlin

/*
kotlinc KotlinClassesMore.kt -include-runtime -d classes.jar
java -jar classes.jar
*/

//______________________________________________________________

data class Grade( val letter: Char, val points: Double, val credits: Double )

///			Primary Constructor
// Here constructor Is Keyword Is Optional
open class Person constructor( var firstName: String, var lastName: String = "" ) {
	// val fullName = "$firstName $lastName"
	fun fullName() = "$firstName $lastName"
}

open class Student(
	// var firstName: String, 
	// var lastName: String, 	
	firstName: String, // Not Redefining Properties Coming From Parent Class
	lastName: String, 
	var grades: MutableList<Grade> = mutableListOf<Grade>()
): Person( firstName, lastName ) {
// ): Person( ) { //  error: no value passed for parameter 'firstName

	fun recordGrades( grade: Grade ) {
		grades.add( grade )
	}
}

fun playWithClassesAndObjects() {
	val gabbar = Person( firstName = "Gabbar", lastName = "Singh" )
	val alice = Student( firstName = "Alice", lastName = "Carol" )

	println( gabbar.fullName() )
	println( alice.fullName() )

	val history = Grade( letter = 'B', points = 9.0, credits = 3.0 )
	alice.recordGrades( history )
}

//______________________________________________________________
// OVERRIDING PROPERTY

open class BandMember( firstName: String, lastName: String ) : Student(firstName, lastName) {
	// Property Have 3 Things Associated With It: 
	//		1. Member Variable
	//		2. Getter
	//		3. Setter
	// error: 'minimumPracticeTime' in 'BandMember' is final and cannot be overridden
	open val minimumPracticeTime: Int
		get() { return 2 }
}

class TablaPlayer( firstName: String, lastName: String ) : BandMember(firstName, lastName) {
	override val minimumPracticeTime: Int
		get() { return super.minimumPracticeTime * 2 }
}

fun playWithTypeChecks() {
	val zakirHusaain: Person = TablaPlayer( firstName = "Zakir", lastName = "Husain" )
	var classMonitor = Student( firstName = "Visawnath", lastName = "Anand" )

	println( zakirHusaain.fullName() )
	println( classMonitor.fullName() )

	println( zakirHusaain is TablaPlayer )
	println( zakirHusaain is BandMember )
	println( zakirHusaain is Student )
	println( zakirHusaain is Person )

	println( classMonitor is TablaPlayer )
	println( classMonitor is BandMember )
	println( classMonitor is Student )
	println( classMonitor is Person )

	println( zakirHusaain.minimumPracticeTime )
	println( (zakirHusaain as BandMember).minimumPracticeTime )
}


//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________
//______________________________________________________________

fun main() {
	println("\nFunction : playWithClassesAndObjects")
	playWithClassesAndObjects()

	println("\nFunction : playWithTypeChecks")
	playWithTypeChecks()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

