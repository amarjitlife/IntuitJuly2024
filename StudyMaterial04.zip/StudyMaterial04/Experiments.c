
#include <stdio.h> 
#include <limits.h>

//_____________________________________________________
//_____________________________________________________

void playWithSum() {
	int a, b, result = 0;

	a = 2147483647;
	b = 2;
	result = sum( a, b );
	printf("\nResult : %d", result );

	a = -2147483648;
	b = -2;
	result = sum( a, b );
	printf("\nResult : %d", result );
}

//_____________________________________________________

signed int summation(signed int a, signed int b) {
  signed int result = 0;

	// Type Safe Code: Respecting Type Defintion  
  if (((b > 0) && (a > (INT_MAX - b))) ||
      ((b < 0) && (a < (INT_MIN - b)))) {
    /* Handle error */
    printf("Cann't Calculate Sum For Given Values");
  } else {
    result = a + b;
  }
    return result;
  /* ... */
}

//_____________________________________________________

int sum( int a, int b ) { return a + b; }
int sub( int a, int b ) { return a - b; }
int mul( int a, int b ) { return a * b; }


// Polymorphic Function
//		Mechanims: By Behvaiour To Behvaoiur
int calculator( int a, int b, int (*operation)(int, int) ) {
	return operation( a, b );
}

void playWithCalculator() {
	int a = 40, b = 20, result = 0;

	result = calculator( a, b, sum );
	printf("\nResult : %d", result);

	result = calculator( a, b, sub );
	printf("\nResult : %d", result);

	result = calculator( a, b, mul );
	printf("\nResult : %d", result);
}

// Function: playWithCalculator
// Result : 60
// Result : 20

//_____________________________________________________

// Encapsulation
typedef struct human_type  {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBangra() {
	printf("\nOye Hoyee.... Ballleee Ballleee!!!!");
}

void doHipHop() {
	printf("\nDoing Hip Hop...");
}

void playWithHuman() {
	// Human gabbar = { 420, "Gabbar Singh" };
	// Human basanti = { 100, "Basanti" };

	Human gabbar = { 420, "Gabbar Singh", doBangra };
	Human basanti = { 100, "Basanti", doHipHop };

	printf("\n ID : %d", gabbar.id );
	printf("\n Name: %s", gabbar.name );
	gabbar.dance();

	printf("\n ID : %d", basanti.id );
	printf("\n Name: %s", basanti.name );	
	basanti.dance();
}

//_____________________________________________________

void playWithPointers() {
	int a = 20;

	// &a Will Give Address Of a
	// In Definition * Means ptr Is Pointer Variable
	///		i.e. It Will Store Address
	int *ptr = &a; // RHS Address Of a

	int value1 = a;
	int value2 = *ptr; // Here * Used As Derefence Operator

	printf("\n a = %d, ptr = %p ", a , ptr );
	printf("\n value1 = %d, value2 = %d", value1, value2);
}

//_____________________________________________________

void something() {
	printf("\nSomething Happened....");
}

void playWithFuntionPointers() {
	void (*functionPointer)();

	functionPointer = something;

	functionPointer();
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

int main() {
	printf("\n\nFunction: playWithSum" );
	playWithSum();

	printf("\n\nFunction: playWithCalculator" );
	playWithCalculator();

	printf("\n\nFunction: playWithHuman" );
	playWithHuman();

	printf("\n\nFunction: playWithFuntionPointers" );
	playWithFuntionPointers();
	
	// printf("\n\nFunction: " );
	// printf("\nFunction: " );
	// printf("\nFunction: " );
	// printf("\nFunction: " );
	
	return 0;
}

// Function: playWithSum
// Result : -2147483647
// Result :  2147483646
